import * as fcl from "@onflow/fcl"
import { Address } from "@onflow/types"
import FETCH_ACCOUNT_ITEMS_SCRIPT from "src/cadence/scripts/get_account_items.cdc"

export async function fetchAccountItems(address) {
  if (address == null) return Promise.resolve([])

  const fetchAccountItemsScript = await (await fetch(FETCH_ACCOUNT_ITEMS_SCRIPT)).text();

  // prettier-ignore
  return await fcl.query({
    cadence: fetchAccountItemsScript,
    args: (_arg, _t) => [fcl.arg(address, Address)]
  })
}
