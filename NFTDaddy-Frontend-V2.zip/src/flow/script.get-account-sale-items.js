import * as fcl from "@onflow/fcl"
import { Address } from "@onflow/types"
import FETCH_ACCOUNT_SALE_ITEMS_SCRIPT from "src/cadence/scripts/get_account_sale_items.cdc"

export async function fetchAccountSaleItems(address) {
  if (address == null) return Promise.resolve([])

  const fetchAccountSaleItemsScript = await (await fetch(FETCH_ACCOUNT_SALE_ITEMS_SCRIPT)).text();

  // prettier-ignore
  return await fcl.query({
    cadence: fetchAccountSaleItemsScript,
    args: (_arg, _t) => [fcl.arg(address, Address)]
  })
}
