// prettier-ignore
import { tx } from "src/flow/util/tx"
import MINT_AND_LIST_TRANSACTION from "src/cadence/transactions/mint_and_list.cdc"
import * as fcl from "@onflow/fcl"
import * as t from "@onflow/types"

export async function mintAndList(name, description, thumbnail, royaltyCut, expireTimestamp, saleItemPrice, opts = {}) {
  const mintAndListTxScript = await (await fetch(MINT_AND_LIST_TRANSACTION)).text();

  return tx(
    {
      cadence: mintAndListTxScript,
      args: [
        fcl.arg(name, t.String),
        fcl.arg(description, t.String),
        fcl.arg(thumbnail, t.String),
        fcl.arg(royaltyCut.toFixed(2), t.UFix64),
        fcl.arg(saleItemPrice.toFixed(2), t.UFix64),
        fcl.arg("NFT Daddy", t.String),
        fcl.arg("0.00", t.UFix64),
        fcl.arg(expireTimestamp.toString(), t.UInt64),
        fcl.arg([], t.Array(t.Address)),
      ],
      limit: 1000,
    },
    opts
  )
}
