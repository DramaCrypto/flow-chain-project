import { send, decode, script, args, arg } from "@onflow/fcl"
import { Address } from "@onflow/types"
import IS_ACCOUNT_INITIALIZED_SCRIPT from "src/cadence/scripts/is_account_initialized.cdc"

export async function isAccountInitialized(address) {
  if (address == null) return Promise.resolve(false)

  const accountInitializedScript = await (await fetch(IS_ACCOUNT_INITIALIZED_SCRIPT)).text();

  // prettier-ignore
  return send([
    script(accountInitializedScript),
    args([
      arg(address, Address)
    ])
  ]).then(decode)
}
