// prettier-ignore
import { tx } from "src/flow/util/tx"
import SELL_ITEM_TRANSACTION from "src/cadence/transactions/sell_item.cdc"
import * as fcl from "@onflow/fcl"
import * as t from "@onflow/types"

export async function listItem(saleItemID, expireTimestamp, saleItemPrice, opts = {}) {
  const sellItemTxScript = await (await fetch(SELL_ITEM_TRANSACTION)).text();

  return tx(
    {
      cadence: sellItemTxScript,
      args: [
        fcl.arg(saleItemID.toString(), t.UInt64),
        fcl.arg(saleItemPrice.toFixed(2), t.UFix64),
        fcl.arg("NFT Daddy", t.String),
        fcl.arg("0.00", t.UFix64),
        fcl.arg(expireTimestamp.toString(), t.UInt64),
        fcl.arg([], t.Array(t.Address)),
      ],
      limit: 1000,
    },
    opts
  )
}
