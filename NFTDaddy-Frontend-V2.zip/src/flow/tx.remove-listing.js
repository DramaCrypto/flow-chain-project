// prettier-ignore
import { tx } from "src/flow/util/tx"
import REMOVE_ITEM_TRANSACTION from "src/cadence/transactions/remove_item.cdc"
import * as fcl from "@onflow/fcl"
import * as t from "@onflow/types"

export async function removeListing(listingResourceID, opts = {}) {
  const removeItemTxScript = await (await fetch(REMOVE_ITEM_TRANSACTION)).text();

  return tx(
    {
      cadence: removeItemTxScript,
      args: [
        fcl.arg(listingResourceID, t.UInt64),
      ],
      limit: 1000,
    },
    opts
  )
}
