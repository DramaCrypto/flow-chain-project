// prettier-ignore
import { tx } from "src/flow/util/tx"
import BUY_ITEM_TRANSACTION from "src/cadence/transactions/buy_item.cdc"
import * as fcl from "@onflow/fcl"
import * as t from "@onflow/types"

export async function buyItem(listingResourceID, storefrontAddress, commissionRecipient, opts = {}) {
  const buyItemTxScript = await (await fetch(BUY_ITEM_TRANSACTION)).text();

  return tx(
    {
      cadence: buyItemTxScript,
      args: [
        fcl.arg(listingResourceID, t.UInt64),
        fcl.arg(storefrontAddress, t.Address),
        fcl.arg(commissionRecipient, t.Address),
      ],
      limit: 1000,
    },
    opts
  )
}
