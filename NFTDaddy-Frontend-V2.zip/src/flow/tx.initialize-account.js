// prettier-ignore
import { tx } from "src/flow/util/tx"
import INITIALIZE_ACCOUNT_TRANSACTION from "src/cadence/transactions/initialize_account.cdc"

export async function initializeAccount(opts = {}) {
  // prettier-ignore
  const initializeAccountTxScript = await (await fetch(INITIALIZE_ACCOUNT_TRANSACTION)).text();

  return tx(
    {
      cadence: initializeAccountTxScript,
      limit: 1000,
    },
    opts
  )
}
