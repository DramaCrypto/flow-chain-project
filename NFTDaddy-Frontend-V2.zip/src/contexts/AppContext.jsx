/* eslint-disable react-hooks/exhaustive-deps */
import * as fcl from "@onflow/fcl"
import PropTypes from "prop-types"
import { createContext, useCallback, useEffect, useState } from "react"
import { isAccountInitialized as isAccountInitializedTx } from "src/flow/script.is-account-initialized"

export const AppContext = createContext({
  currentUser: null,
  isAccountInitialized: null,
  checkIsAccountInitialized: () => null,
})

export const AppContextProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null)
  const [isAccountInitStateLoading, setIsAccountInitStateLoading] =
    useState(false)
  const [isAccountInitialized, setIsAccountInitialized] = useState(null)

  const checkIsAccountInitialized = useCallback(() => {
    if (currentUser?.addr) {
      setIsAccountInitStateLoading(true)
      isAccountInitializedTx(currentUser?.addr).then(data => {
        setIsAccountInitialized(data.DaddyNFT && data.DaddyNFTMarket)
        setIsAccountInitStateLoading(false)
      })
    }
  }, [currentUser?.addr])

  useEffect(
    () =>
      fcl.currentUser().subscribe(newUser => {
        if (newUser?.loggedIn) {
          setCurrentUser(newUser)
        } else {
          setCurrentUser(null)
        }
      }),
    []
  )

  useEffect(() => {
    checkIsAccountInitialized()
  }, [checkIsAccountInitialized])

  const value = {
    currentUser,
    isAccountInitStateLoading,
    isAccountInitialized,
    checkIsAccountInitialized,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

AppContextProvider.propTypes = {
  children: PropTypes.node,
}
