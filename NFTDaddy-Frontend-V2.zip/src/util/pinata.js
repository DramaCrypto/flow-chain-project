import pinataSDK from '@pinata/sdk';
import publicConfig from 'src/global/publicConfig';

export const getIpfsHashFromJSON = async (data) => {
  const pinata = pinataSDK(publicConfig.pinataApiKey, publicConfig.pinataSecretApiKey);
  const result = await pinata.pinJSONToIPFS(data, null);
  const hash = result.IpfsHash;
  return hash;
};

export const getIpfsHashFromFile = async (file) => {
  return new Promise((resolve, reject) => {
    var headers = new Headers();
    headers.append("pinata_api_key", publicConfig.pinataApiKey);
    headers.append("pinata_secret_api_key", publicConfig.pinataSecretApiKey);
    var formdata = new FormData();
    formdata.append("file", file);
    const requestOptions = {
      method: 'POST',
      headers: headers,
      body: formdata
    };
    fetch("https://api.pinata.cloud/pinning/pinFileToIPFS", requestOptions)
      .then(r => r.json())
      .then(r => {
        resolve(r.IpfsHash)
      })
      .catch(error => reject(error))
  })
};
