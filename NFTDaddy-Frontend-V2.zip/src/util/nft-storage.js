import publicConfig from 'src/global/publicConfig';
import { NFTStorage } from "nft.storage/dist/bundle.esm.min.js";

export const uploadToStorage = async (file) => {
  const client = new NFTStorage({ token: publicConfig.nftStorageApiKey });
  const cid = await client.storeBlob(file);
  return cid;
};