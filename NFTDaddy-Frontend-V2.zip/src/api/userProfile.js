import { callGet, callPost } from './request';

export const getUserList = async () => {
    const { data, err } = await callGet(`/getUserList`);
    if (data && !err && data.status === "success") {
        return data.userList;
    } else {
        console.error(err);
        return null;
    }
};

export const getUserProfile = async (walletAddress) => {
    const { data, err } = await callGet(`/getUserProfile/${walletAddress}`);
    if (data && !err && data.status === "success") {
        return data.userProfile;
    } else {
        console.error(err);
        return null;
    }
};

export const updateUserProfile = async (walletAddress, name, description, avatarImage, bannerImage, twitter, discord, instagram, telegram) => {
    const paramters = {
        walletAddress: walletAddress,
        name: name,
        description: description,
        avatarImage: avatarImage,
        bannerImage: bannerImage,
        twitter: twitter,
        discord: discord,
        instagram: instagram,
        telegram: telegram,
    }
    const { data, err } = await callPost('/updateUserProfile', paramters);
    if (data && !err) {
        return true;
    } else {
        console.error(err);
        return false;
    }
};