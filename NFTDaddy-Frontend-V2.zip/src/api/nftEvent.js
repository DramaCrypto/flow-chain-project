import { callGet } from './request';

export const getNFTEvents = async (nftID, walletAddress) => {
    const { data, err } = await callGet(`/getNFTEvents?nftID=${nftID}&walletAddress=${walletAddress}`);
    if (data && !err && data.status === "success") {
        return data.events;
    } else {
        console.error(err);
        return null;
    }
};
