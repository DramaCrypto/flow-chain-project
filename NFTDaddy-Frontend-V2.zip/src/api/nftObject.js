import { callGet } from './request';

export const getNFTObjectList = async (start, count, sortField, sortOrder, searchKey) => {
    const { data, err } = await callGet(`/getNFTObjectList?start=${start}&count=${count}&sortField=${sortField}&sortOrder=${sortOrder}&searchKey=${searchKey}`);
    if (data && !err && data.status === "success") {
        return {
            totalCount: data.totalCount,
            nftList: data.nftList
        };
    } else {
        console.error(err);
        return null;
    }
};

export const getNFTObjectDetail = async (nftID) => {
    const { data, err } = await callGet(`/getNFTObjectDetail/${nftID}`);
    if (data && !err && data.status === "success") {
        return data.nftDetail;
    } else {
        console.error(err);
        return null;
    }
};