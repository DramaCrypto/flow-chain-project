import React, { useEffect, useState } from "react";
import Breakpoint, { BreakpointProvider, setDefaultBreakpoints } from "react-socks";
import { Link } from '@reach/router';
import useOnclickOutside from "react-cool-onclickoutside";
// import { useNavigate, useLocation } from 'react-router-dom';
import { getUserProfile } from 'src/api/userProfile'
import useAuth from "src/hooks/useAuth";
import useAppContext from "src/hooks/useAppContext";
import useFLOWBalance from "src/hooks/useFLOWBalance";
import { formattedCurrency } from "src/util/currency";
import './style.scss'
import { initializeAccount } from "src/flow/tx.initialize-account";
import { useLoader } from 'src/hooks/useLoader'
import toast from "react-hot-toast";
setDefaultBreakpoints([
  { xs: 0 },
  { l: 1199 },
  { xl: 1200 }
]);

const NavLink = props => (
  <Link
    {...props}
    getProps={({ isCurrent }) => {
      // the object returned here is passed to the
      // anchor element's props
      return {
        className: isCurrent ? 'active' : 'non-active',
      };
    }}
  />
);
const Header = function (props) {
  const [openMenu4, setOpenMenu4] = React.useState(false);

  const handleBtnClick4 = () => {
    setOpenMenu4(!openMenu4);
  };
  const closeMenu4 = () => {
    setOpenMenu4(false);
  };

  const ref4 = useOnclickOutside(() => {
    closeMenu4();
  });

  const [showmenu, btn_icon] = useState(false);
  useEffect(() => {
    const header = document.getElementById("myHeader");
    const totop = document.getElementById("scroll-to-top");
    const sticky = header.offsetTop;
    const scrollCallBack = window.addEventListener("scroll", () => {
      btn_icon(false);
      if (window.pageYOffset > sticky) {
        header.classList.add("sticky");
        totop.classList.add("show");

      } else {
        header.classList.remove("sticky");
        totop.classList.remove("show");
      }

    });
    return () => {
      window.removeEventListener("scroll", scrollCallBack);
    };
  }, []);

  const { currentUser, isAccountInitialized } = useAppContext();

  const { logIn, logOut } = useAuth();
  const { data: flowBalance, isLoading } = useFLOWBalance(currentUser?.addr)

  const [setLoading, setMessage] = useLoader();

  const funcInitializeAccount = async () => {
    setMessage("Initializing Account...");
    setLoading(true);
    try {
      const onSuccess = () => {
        toast.success("Account Initialized Successfully.");
        setTimeout(() => {
          window.location.reload();
        }, 3000);
      };

      const onError = () => {
        toast("Account Initializing Failed.");
      }

      await initializeAccount({
        onError: onError,
        onSuccess: onSuccess
      });

    } catch (error) {
      console.error(error);
      toast("Account Initializing Failed.");
    }
    setLoading(false);
  }
  const [userData, setUserData] = useState();

  useEffect(() => {

    async function fetchUserData(addr) {
      try {
        const userProfile = await getUserProfile(addr);
        setUserData(userProfile);
      } catch (e) {
        console.log(e);
      }
    }
    if (currentUser) {
      fetchUserData(currentUser?.addr)
    }
  }, [currentUser])

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      window.open(`/explore?${event.target.value}`, "_self")
    }
  }

  return (
    <header id="myHeader" className='myHeader navbar white'>
      <div className='container'>
        <div className='row w-100-nav'>
          <div className='logo px-0'>
            <div className='navbar-title navbar-item'>
              <NavLink to="/">
                <img
                  src="/img/finallogo_white.png"
                  className="logo_img"
                  alt="#"
                  style={{ height: 'min(3rem, 8vw)' }}
                />
                
              </NavLink>
            </div>
          </div>
          <div className='search'>
            <input id="quick_search" className="xs-hide" name="quick_search" placeholder="search item here..." type="text"
              // value={filter} 
              onKeyDown={handleKeyDown}
            // onChange={(e)=>onFilter(e.target.value)} 
            />
          </div>
          <BreakpointProvider>
            <Breakpoint l down>
              {showmenu &&
                <div className='menu'>
                  <div className="spacer-10"></div>
                  <div className="spacer-10"></div>
                  <div className='navbar-item'>
                    <NavLink to="/" onClick={() => btn_icon(!showmenu)}>
                      Home
                    </NavLink>
                  </div>
                  <div className='navbar-item'>
                    <NavLink to="/explore2" onClick={() => btn_icon(!showmenu)}>
                      Explore
                    </NavLink>
                  </div>
                  <div className='navbar-item'>
                    <NavLink to="/create" onClick={() => btn_icon(!showmenu)}>Create</NavLink>
                  </div>
                  <div className='navbar-item'>
                    <NavLink to="/activity" onClick={() => btn_icon(!showmenu)}>
                      Activity
                    </NavLink>
                  </div>
                </div>
              }
            </Breakpoint>

            <Breakpoint xl>
              <div className='menu'>
                <div className='navbar-item'>
                  <NavLink to="/">
                    Home
                    <span className='lines'></span>
                  </NavLink>
                </div>
                <div className='navbar-item'>
                  <NavLink to="/explore">
                    Explore
                    <span className='lines'></span>
                  </NavLink>
                </div>
                <div className='navbar-item'>
                  <NavLink to="/create">
                    Create
                    <span className='lines'></span>
                  </NavLink>
                </div>
                <div className='navbar-item'>
                  <NavLink to="/activity">
                    Activity
                    <span className='lines'></span>
                  </NavLink>
                </div>
              </div>
            </Breakpoint>
          </BreakpointProvider>

          <div className='mainside'>
            {!currentUser ? <button onClick={logIn} className="btn-main">Connect Wallet</button> :

              <div ref={ref4}>
                <div className="dropdown-custom btn account-dropdonw">
                  <div className="row-div">
                    <button className="btn-main"
                      onMouseLeave={closeMenu4}
                      onMouseOver={closeMenu4}
                    >
                      {!isLoading && `FLOW : ${formattedCurrency(flowBalance)}`}
                    </button>
                    <img
                      src={userData?.avatarImage || "/img/author/avatar.png"}
                      className="img-fluid d-3"
                      alt="#"
                      style={{ height: 'min(2.7rem, 9vw)', zIndex: 999 }}
                      ref={ref4}
                      onClick={handleBtnClick4}
                    />
                  </div>
                  {openMenu4 && (
                    <div className='item-dropdown'>
                      <div className="account-drop dropdown" onClick={closeMenu4}>
                        <div className="item-div">{currentUser?.addr}</div>
                        {isAccountInitialized ?
                          <NavLink to={`/profile/${currentUser?.addr}`}>Profile</NavLink> :
                          <div className="item-div" onClick={funcInitializeAccount}>Initialize Account</div>
                        }
                        <div className="item-div" onClick={logOut}>Sign Out</div>
                      </div>
                    </div>
                  )}
                </div>

              </div>}
          </div>
        </div>

        <button className="nav-icon" onClick={() => btn_icon(!showmenu)}>
          <div className="menu-line white"></div>
          <div className="menu-line1 white"></div>
          <div className="menu-line2 white"></div>
        </button>

      </div>
    </header>
  );
}
export default Header;