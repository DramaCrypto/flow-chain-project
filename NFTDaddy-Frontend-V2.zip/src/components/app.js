import React, { useState } from "react";
import { Router, Location, Redirect } from '@reach/router';
import ScrollToTopBtn from './menu/ScrollToTop';
import Header from './menu/header';
import Home from './pages/home/Home';
import Explore from './pages/explore/Explore';
import ItemDetail from './pages/itemDetail/ItemDetail';
import Profile from './pages/profile/Profile';
import EditProfile from './pages/profile/EditProfile';
import Create from './pages/create';
import Activity from './pages/active/activity';
import { SWRConfig } from "swr";
import { Toaster } from 'react-hot-toast';
import "../global/fclConfig";
import { AppContextProvider } from "../contexts/AppContext"
import { createGlobalStyle } from 'styled-components';
import { LoadingProvider } from 'src/hooks/useLoader';

const GlobalStyles = createGlobalStyle`
  :root {
    scroll-behavior: unset;
  }
`;

export const ScrollTop = ({ children, location }) => {
  React.useEffect(() => window.scrollTo(0, 0), [location])
  return children
}

const PosedRouter = ({ children }) => (
  <Location>
    {({ location }) => (
      <div id='routerhang'>
        <div key={location.key}>
          <Router location={location}>
            {children}
          </Router>
        </div>
      </div>
    )}
  </Location>
);

export default function App() {
  const [filter, setFilter] = useState('')
  const onFilter = (e) => {
    setFilter(e)
  }
  return (
    <LoadingProvider>
      <Toaster
        position="top-center"
        toastOptions={{
          success: {
            duration: 3000,
            style: {
            }
          },
          error: {
            duration: 3000,
            style: {
            }
          },
        }}
      />
      <div className="wraper">
        <SWRConfig value={{ provider: () => new Map() }}>
          <AppContextProvider>
            <GlobalStyles />
            <Header filter={filter} onFilter={onFilter} />
            <PosedRouter>
              <ScrollTop path="/">
                <Home exact path="/">
                  <Redirect to="/home" />
                </Home>
                {/* <Explore path="/explore"/> */}
                <Explore path="/explore" filter={filter} />
                <ItemDetail path="/ItemDetail/:nftID" />
                <Profile path="/profile/:walletAddress" />
                <EditProfile path="/edit-profile" />
                <Create path="/create" />
                <Activity path="/activity" />
              </ScrollTop>
            </PosedRouter>
            <ScrollToTopBtn />
          </AppContextProvider>
        </SWRConfig>

      </div>
    </LoadingProvider>
  )
};