import Particle from '../../components/Particle';
import SliderMainParticle from '../../components/SliderMainParticle';
import FeatureBox from '../../components/FeatureBox';
import CarouselNew from '../../components/CarouselNew';
import Authorlist from '../../components/authorList/Authorlist';
import Footer from '../../components/footer';
import { createGlobalStyle } from 'styled-components';
import {getNFTObjectList} from 'src/api/nftObject'
import {getUserList} from 'src/api/userProfile'
import { useEffect, useState } from "react";
import './home.scss'
// const GlobalStyles = createGlobalStyle`
//   header#myHeader .logo .d-block{
//     display: none !important;
//   }
//   header#myHeader .logo .d-none{
//     display: block !important;
//   }
//   .navbar .mainside a{
//     background: #8364e2;
//     &:hover{
//       box-shadow: 2px 2px 20px 0px #8364e2;
//     }
//   }
//   .item-dropdown{
//     .dropdown{
//       a{
//         &:hover{
//           background: #8364e2;
//         }
//       }
//     }
//   }
//   .btn-main{
//     background: #8364e2;
//     &:hover{
//       box-shadow: 2px 2px 20px 0px #8364e2;
//     }
//   }
//   p.lead{
//     color: #a2a2a2;
//   }
//   .navbar .navbar-item .lines{
//     border-bottom: 2px solid #8364e2;
//   }
//   .jumbotron.no-bg{
//     height: 100vh;
//     overflow: hidden;
//     background-repeat: repeat;
//     background-size: cover;
//     background-position: bottom;
//     background-repeat: no-repeat;
//   }
//   #tsparticles{
//     top: 0;
//   }
//   .text-uppercase.color{
//     color: #8364e2;
//   }
//   .de_count h3 {
//     font-size: 36px;
//     margin-bottom: 0px;
//   }
//   .de_count h5{
//     font-size: 14px;
//     font-weight: 500;
//   }
//   h2 {
//     font-size: 30px;
//   }
//   .box-url{
//     text-align: center;
//     h4{
//       font-size: 16px;
//     }
//   }
//   .de_countdown{
//     border: solid 2px #8364e2;
//   }
//   .author_list_pp, .author_list_pp i, 
//   .nft_coll_pp i, .feature-box.style-3 i, 
//   footer.footer-light #form_subscribe #btn-subscribe i, 
//   #scroll-to-top div{
//     background: #8364e2;
//   }
//   footer.footer-light .subfooter .social-icons span i{
//     background: #403f83;
//   }
//   .author_list_pp:hover img{
//     box-shadow: 0px 0px 0px 2px #8364e2;
//   }
//   .nft__item_action span{
//     color: #8364e2;
//   }
//   .feature-box.style-3 i.wm{
//     color: rgba(131,100,226, .1);
//   }
//   @media only screen and (max-width: 1199px) {
//     .navbar{
      
//     }
//     .navbar .menu-line, .navbar .menu-line1, .navbar .menu-line2{
//       background: #fff;
//     }
//     .item-dropdown .dropdown a{
//       color: #fff !important;
//     }
//   }
// `;

const GlobalStyles = createGlobalStyle`
  header#myHeader.navbar.sticky.white {
    background: #212428;
    border-bottom: 0;
    box-shadow: 0 4px 20px 0 rgba(10,10,10, .8);
  }
  header#myHeader.navbar .search #quick_search{
    color: #fff;
    background: rgba(255, 255, 255, .1);
  }
  header#myHeader.navbar.white .btn, .navbar.white a, .navbar.sticky.white a{
    color: #fff;
  }
  header#myHeader .dropdown-toggle::after{
    color: #fff;
  }
  header#myHeader .logo .d-block{
    display: none !important;
  }
  header#myHeader .logo .d-none{
    display: none !important;
  }
  header#myHeader .logo .d-3{
    display: block !important;
  }
  footer.footer-light .subfooter span img.d-1{
    display: none !important;
  }
  footer.footer-light .subfooter span img.d-3{
    display: inline-block !important;
  }
  .de_countdown{
    right: 10px;
    color: #fff;
  }
  .author_list_pp{
    margin-left:0;
  }
  footer.footer-light .subfooter{
    border-top: 1px solid rgba(255,255,255,.1);
  }
`;


const Home= () => {
  const [nftData, setNftData] = useState();
  const [sellerList, setSleerList] = useState([]);
  useEffect(() => {
    async function fetchItems() {
      try {
        const _items = await getNFTObjectList(0, 6, "listedTime", "desc", "")
        setNftData(_items?.nftList);
      } catch (e) {
        console.log(e);
      }
    }

    async function fetchSellers() {
      try {
        const _sellers = await getUserList(0, 6, "listedTime", "desc", "")
        setSleerList(_sellers);
      } catch (e) {
        console.log(e);
      }
    }

    fetchItems();
    fetchSellers();
  }, [])
  return (
    <div className='home'>
    <GlobalStyles />
        <section className="jumbotron no-bg homeSection" style={{backgroundImage: `url(${'./img/8.jpg'})`}}>
        <Particle/>
          <SliderMainParticle/>
        </section>

        <section className='container no-bottom'>
          <div className="row">
              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/blocto.png" alt="" className="mb20"/>
                      <h4>Blocto</h4>
                  </span>
              </div>

              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/610d3a7803914845d448b3a1_math wallet.png" alt="" className="mb20"/>
                      <h4>Math Wallet</h4>
                  </span>
              </div>       

              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/ledger.png" alt="" className="mb20"/>
                      <h4>Ledger</h4>
                  </span>
              </div>    

              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/60f29fd3fb0e0b11aa95f5e6_dapper.png" alt="" className="mb20"/>
                      <h4>Dapper</h4>
                  </span>
              </div>

              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/talk.png" alt="" className="mb20"/>
                      <h4>Talken</h4>
                  </span>
              </div>

              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/60fbc006e941fcc72a8a9a9a_Anchorage.png" alt="" className="mb20"/>
                      <h4>Anchorage Digital</h4>
                  </span>
              </div>    
              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/6225ea47368be32b07c91b7f_copper logo.png" alt="" className="mb20"/>
                      <h4>Copper</h4>
                  </span>
              </div> 
              <div className="walletItem mb30">
                  <span className="box-url">
                      <img src="/img/wallet/finona.png" alt="" className="mb20"/>
                      <h4>Finoa</h4>
                  </span>
              </div>                                    
          </div>
        </section>

        <section className='container no-top no-bottom'>
          <div className='row'>
            <div className="spacer-double"></div>
            <div className='col-lg-12 mb-2'>
                <h2>New Items</h2>
            </div>
          </div> 
          <CarouselNew nftList = {nftData}/>
        </section>

        <section className='container no-top no-bottom'>
          <div className='row'>
            <div className="spacer-double"></div>
            <div className='col-lg-12'>
                <h2>Top Sellers</h2>
            </div>
            <div className='col-lg-12'>
              <Authorlist sellerList = {sellerList}/>
            </div>
          </div>
        </section>

        <section className='container no-top'>
          <div className='row'>
              <div className="spacer-double"></div>
              <div className='col-lg-12 mb-3'>
                <h2>Create and Sell Now</h2>
              </div>
              <FeatureBox/>
          </div>
        </section>

      <Footer />

    </div>
  );
}
export default Home;