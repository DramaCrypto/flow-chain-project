import React from "react";
import Clock from "../../components/Clock";
import Footer from '../../components/footer';
import ListModal from '../../components/modals/ListModal';
import { createGlobalStyle } from 'styled-components';
import { getNFTObjectDetail } from 'src/api/nftObject'
import { useEffect, useState } from "react";
import { useLocation } from "@reach/router";
import { getUserList } from 'src/api/userProfile'
import { getNFTEvents } from 'src/api/nftEvent'
import './itemDetail.scss'
import moment from 'moment'
import { useLoader } from 'src/hooks/useLoader'
import { removeListing } from "src/flow/tx.remove-listing";
import { buyItem } from "src/flow/tx.buy-item";
import { listItem } from "src/flow/tx.list-item";
import toast from 'react-hot-toast';
import useAppContext from "src/hooks/useAppContext";

const GlobalStyles = createGlobalStyle`
  header#myHeader.navbar.white {
    background: #212428;
  }
`;

const Colection = function () {
    const [setLoading, setMessage] = useLoader();
    const location = useLocation();
    const mftID = location.pathname.split('/').pop();
    const [nftDetail, setNftDtail] = useState();
    const [userList, setUserList] = useState([]);
    const [activityList, setActivityList] = useState([]);
    const { currentUser } = useAppContext();

    useEffect(() => {

        async function fetchUsers() {
            try {
                const _sellers = await getUserList()
                setUserList(_sellers);
            } catch (e) {
                console.log(e);
            }
        }
        async function fetchActivity() {
            try {
                const _activity = await getNFTEvents(mftID, "")
                setActivityList(_activity)
            } catch (e) {
                console.log(e);
            }
        }

        async function fetchDetails() {
            try {
                const _details = await getNFTObjectDetail(mftID)
                setNftDtail(_details);
            } catch (e) {
                console.log(e);
            }
        }
        fetchDetails();
        fetchUsers();
        fetchActivity()
    }, [mftID])

    const [userName, setUserName] = useState('');
    const [userImg, setUserImg] = useState('');
    const [ownerName, setOwnerName] = useState('');
    const [ownerImg, setOwneImg] = useState('');
    useEffect(() => {
        var user = userList.find(user => user?.walletAddress.includes(nftDetail?.creator))

        setUserName(user?.name)
        setUserImg(user?.avatarImage)

        var owner = userList.find(user => user?.walletAddress.includes(nftDetail?.owner))

        setOwnerName(owner?.name)
        setOwneImg(owner?.avatarImage)
    }, [userList, nftDetail])

    const funcRemoveListing = async () => {
        setLoading(true);
        setMessage('Listing Removing...');
        try {
            const onSuccess = () => {
                toast.success("Listing removed successfully");
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            };

            const onError = () => {
                toast.error("Listing remove failed");
            }
            await removeListing(nftDetail?.listingResourceID, {
                onError: onError,
                onSuccess: onSuccess
            });

        } catch (error) {
            toast.error("Listing remove failed");
            console.error(error);
        }
        setLoading(false);
    }

    const funcPurchase = async () => {
        setLoading(true);
        setMessage('Purchase NFT Now...');
        try {
            const onSuccess = () => {
                toast.success("NFT Purchased Successfully");
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            };

            const onError = () => {
                toast.error("NFT Purchase Failed");
            }

            await buyItem(nftDetail?.listingResourceID, nftDetail?.storefrontAddress, nftDetail?.creator, {
                onError: onError,
                onSuccess: onSuccess
            });
        } catch (error) {
            toast.error("NFT Purchase Failed");
            console.error(error);
        }
        setLoading(false);
    }

    const funcListing = async (saleItemPrice, expireTimestamp) => {
        setLoading(true);
        setMessage('NFT is listinig...');
        try {
            const onSuccess = () => {
                toast.success("NFT Listed Successfully");
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            };

            const onError = () => {
                toast.error("NFT Listing Failed");
            }

            await listItem(nftDetail?.nftID, expireTimestamp, saleItemPrice, {
                onError: onError,
                onSuccess: onSuccess
            });

        } catch (error) {
            toast.error("NFT Listing Failed");
            console.error(error);
        }
        setLoading(false);
    }
    const [showModal, setShowModal] = useState(false);
    return (
        <>
            <div className="itemDetail">
                <GlobalStyles />
                <section className='container'>
                    <div className='row mt-md-5 pt-md-4'>

                        <div className="col-md-6 text-center">
                            <img src={nftDetail?.thumbnail || "/img/bg-shape-1.jpg"} className="img-fluid img-rounded mb-sm-30" alt="" />
                        </div>
                        <div className="col-md-6">
                            <div className="item_info">
                                {nftDetail?.expiry * 1000 > Date.now() &&
                                    <>
                                        Auctions ends in
                                        <div className="de_countdown">
                                            <Clock deadline={nftDetail?.expiry || 0} />
                                        </div>
                                    </>
                                }
                                <h2>{nftDetail?.name || '-'}</h2>
                                <div className="item_info_counts">
                                    <div className="item_info_type">
                                        {nftDetail?.salePrice || 0} FLOW
                                    </div>
                                </div>
                                <p>{nftDetail?.description || '-'}</p>

                                
                                <div className="row-div">
                                    <div className="mr-5">
                                        <h6>Creator</h6>
                                        <div className="item_author">
                                            <div className="author_list_pp">
                                                <span>
                                                    <img className="lazy" src={userImg || "/img/author/avatar.png"} alt="" />
                                                    <i className="fa fa-check"></i>
                                                </span>
                                            </div>
                                            <div className="author_list_info">
                                                <span>{userName}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <h6>Owner</h6>
                                        <div className="item_author">
                                            <div className="author_list_pp">
                                                <span>
                                                    <img className="lazy" src={ownerImg || "/img/author/avatar.png"} alt="" />
                                                    <i className="fa fa-check"></i>
                                                </span>
                                            </div>
                                            <div className="author_list_info">
                                                <span>{ownerName}</span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div className="spacer-40"></div>
                                {nftDetail?.listed === true &&
                                    <div className="btns-div">
                                        {
                                            nftDetail?.expiry * 1000 < Date.now() &&
                                            <div className="btns-div">
                                                <button className="btn-main out-line mr-5">Expired! Should be listed again.</button>
                                            </div>
                                        }
                                        {
                                            currentUser?.addr === nftDetail?.owner ? <button className="btn-main cancelBtn" onClick={funcRemoveListing} ><i className="fas fa-clock"></i>Cancel Listing</button>
                                                : <button className="btn-main" onClick={funcPurchase}>Purchase</button>
                                        }

                                    </div>
                                }
                                {(nftDetail?.listed === false && currentUser?.addr === nftDetail?.owner) &&
                                    <div className="btns-div">
                                        <button className="btn-main"
                                            onClick={() => setShowModal(true)}
                                        >List on Sale</button>
                                    </div>
                                }
                                <div className="spacer-40"></div>

                                <div className="de_tab">

                                    <ul className="de_nav">
                                        <li id='Mainbtn' className="active">
                                            <span>History</span>
                                        </li>
                                    </ul>

                                    <div className="de_tab_content">
                                        <ul className="activity-list">
                                            {activityList &&
                                                activityList.map((d, k) => {
                                                    const user = userList.find(user => user?.walletAddress.includes(d?.owner))
                                                    // console.log(d?.eventType, user, d?.owner)
                                                    var formatted = moment(parseInt(d?.eventTime * 1000)).format("YYYY/MM/DD hh:MM:ss");
                                                    return (
                                                        <li className="act-row" key={k}>
                                                            <img className="lazy" src={user?.avatarImage || "/img/author/avatar.png"} alt="" />
                                                            <div className="act_list_text">
                                                                <h4>{user?.name || user?.walletAddress || 'No Name'}</h4>
                                                                {d?.eventType} <span className='color go-profile'>by {user?.name || 'No Name'}</span>
                                                                <span className="act_list_date">
                                                                    {formatted}
                                                                </span>
                                                            </div>
                                                            <div className='active-icon'>
                                                                {d?.eventType === 'MINT' && <i className="fas fa-coins"></i>}
                                                                {d?.eventType === 'LIST' && <i className="fas fa-th-list"></i>}
                                                                {d?.eventType === 'DELIST' && <i className="fas fa-list-alt"></i>}
                                                                {d?.eventType === 'SELL' && <i className="fa fa-check"></i>}
                                                            </div>
                                                        </li>
                                                    )
                                                })}
                                        </ul>

                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                </section>
                <Footer />
            </div>
            <ListModal showModal={showModal} setShowModal={setShowModal} funcListing={funcListing} />
        </>
    );
}
export default Colection;