import React from 'react';
import ColumnNewThreeCol from '../../components/ColumnNewThreeCol';
import Footer from '../../components/footer';
import { createGlobalStyle } from 'styled-components';
import {getNFTObjectList} from 'src/api/nftObject'
import {getUserList} from 'src/api/userProfile'
import { useEffect, useState } from "react";
import Select from "react-select";
import FormatsortOptionLabel from './FormatsortOptionLabel';
import './explore.scss'
import { useLocation } from "@reach/router";


const GlobalStyles = createGlobalStyle`
  .navbar {
    border-bottom: solid 1px rgba(255, 255, 255, .1) !important;
  }
`;


const customStyles = {
    menu: (provided, state) => ({
        ...provided,
        border: '1px solid #ffffff13',
        color: '#fff',
        padding: 0,
        background : '#333',
       
      }),
    option: (provided, state) => ({
      ...provided,
      borderBottom: '1px solid #333',
      padding: 3,
      color: '#fff',
      cursor : 'pointer',
      ':hover':{
        backgroundColor : '#555',
      },
      ':active': {
        backgroundColor: '#555'
      },
    }),
    singleValue: (provided, state) => {
        const opacity = state.isDisabled ? 0.5 : 1;
        const transition = 'opacity 300ms';
    
        return { ...provided, opacity, transition };
      }
  }
  


const Explore= (props) => {

    const [nftList, setNftList] = useState([]);
    const [nftOriginalList, setNftOriginalList] = useState([]);

    const [userList, setUserList] = useState([]);
    const location = useLocation();
    const filter = location.search.replace('?', '')
    useEffect(() => {
        if(filter!==''){
            async function fetchItems() {
                try {
                const _temp = await getNFTObjectList(0, 1, "listedTime", "desc", filter)
                const _items = await getNFTObjectList(0, _temp.totalCount, "listedTime", "desc", filter)
                setNftList(_items.nftList)
                } catch (e) {
                console.log(e);
                }
            }
            fetchItems();
        }else{
            async function fetchItems() {
                try {
                  const _temp = await getNFTObjectList(0, 1, "listedTime", "desc", "")
                  const _items = await getNFTObjectList(0, _temp.totalCount, "listedTime", "desc", "")
        
                  setNftList(_items.nftList)
                  setNftOriginalList(_items.nftList)
                } catch (e) {
                  console.log(e);
                }
              }
              fetchItems();
        }
      
  
      async function fetchSellers() {
        try {
          const _sellers = await getUserList()
          setUserList(_sellers);
        } catch (e) {
          console.log(e);
        }
      }
  
      
      fetchSellers();
    }, [filter])


    // Filter by Listed
    const [filterList, setFilterList] = useState([])
    const handleChangeStatus=(e)=>{
        const idx = filterList.indexOf(e.target.value);
        if (idx > -1) filterList.splice(idx, 1) //isExist
        else filterList.push(e.target.value);
        setFilterList([...filterList]);

        if(!filterList.includes('listed' && !filterList.includes('notlisted'))){
            setNftList(nftOriginalList);
        }
    }

    useEffect(() => {
        if(filterList.length === 1){
            if(filterList.includes('listed')){
                const filtered = nftOriginalList.filter(nft=>nft.listed === true)
                setNftList(filtered);
            }else if(filterList.includes('notlisted')){
                const filtered = nftOriginalList.filter(nft=>nft.listed === false)
                setNftList(filtered);
            }
        }else 
        if(filterList.length === 2){
            setNftList(nftOriginalList);
        }
    }, [filterList, nftOriginalList])
    const [sort, setSort] = useState(2)
    const handleSelected = (e) => {
        setSort(e.value);
    }
    useEffect(() => {
        if(sort === 0){
            const sorted = nftList.sort((a, b) => {
                return a.salePrice - b.salePrice;
            });
            setNftList(sorted);
        }else if(sort === 1){
            const sorted = nftList.sort((a, b) => {
                return b.salePrice - a.salePrice;
            });
            setNftList(sorted);
        }else if(sort === 2){
            const sorted = nftList.sort((a, b) => {
                return b.listedTime - a.listedTime;
            });
            setNftList(sorted);
        }else if(sort === 3){
            const sorted = nftList.sort((a, b) => {
                return a.listedTime - b.listedTime;
            });
            setNftList(sorted);
        }else if(sort === 5){
            const sorted = nftList.sort((a, b) => {
                return a.mintedTime - b.mintedTime;
            });
            setNftList(sorted);
        }else if(sort === 4){
            const sorted = nftList.sort((a, b) => {
                return b.mintedTime - a.mintedTime;
            });
            setNftList(sorted);
        }
    }, [sort, setNftList, nftList])

    const options = [
		{ value: 0, label: "Price: Low To High", customAbbreviation: "0" },
		{ value: 1, label: "Price: High To Low", customAbbreviation: "1" },
		{ value: 2, label: "Listed Newest", customAbbreviation: "2" },
		{ value: 3, label: "Listed Oldest", customAbbreviation: "3" },
        { value: 4, label: "Minted Newest", customAbbreviation: "4" },
        { value: 5, label: "Minted Oldest", customAbbreviation: "5" },
	];
    return (
        <div className='explore-page'>
        <GlobalStyles/>
        <section className='container'>
            <div className='row'>
            <div className="filter-div">
                <span className='time-filter'>

                    <Select
                        defaultValue={options[2]}
                        formatOptionLabel={FormatsortOptionLabel}
                        options={options}
                        instanceId='chainSelect'
                        className={`select-gray `}
                        onChange={(e)=>handleSelected(e)}
                        isSearchable={false}
                        isClearable={false}
                        styles = {customStyles}
                    />
                </span>
            </div>

                <div className='col-md-3'>
                    <div className="item_filter_group">
                        <h4>Status</h4>
                        <div className="de_form">
                            <div className="de_checkbox">
                                <input id="listed" name="listed" type="checkbox" value="listed"
                                onChange={(e)=>handleChangeStatus(e)}
                                />
                                <label htmlFor="listed">Listed</label>
                            </div>

                            <div className="de_checkbox">
                                <input id="notlisted" name="notlisted" type="checkbox" 
                                onChange={(e)=>handleChangeStatus(e)}
                                value="notlisted"/>
                                <label htmlFor="notlisted">Not Listed</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-md-9">
                    <ColumnNewThreeCol nftList = {nftList} userList = {userList} sort = {sort}/>
                </div>
                </div>
            </section>


        <Footer />
        </div>

        );
    }
export default Explore;