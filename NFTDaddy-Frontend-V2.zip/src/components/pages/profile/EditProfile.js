import React, { useEffect, useState } from "react";
import Footer from '../../components/footer';
import { createGlobalStyle } from 'styled-components';
import { getUserProfile, updateUserProfile } from 'src/api/userProfile'
import { useLoader } from 'src/hooks/useLoader'
import toast from 'react-hot-toast';
import { uploadToStorage } from "src/util/nft-storage";
import './style.scss'
import useAppContext from "src/hooks/useAppContext";

const GlobalStyles = createGlobalStyle`
  header#myHeader.navbar.white {
    background: #212428;
  }
`;

const EditProfile = function () {
  const { currentUser } = useAppContext();
  const [bannerImage, setBannerImage] = useState(null)
  const [bannerPreImage, setBannerPreImage] = useState(null)
  const [avatarImage, setAvatarImage] = useState(null)
  const [avatarPreImage, setAvatarPreImage] = useState(null)

  const [name, setName] = useState('')
  const [isNameValid, setIsNameValid] = useState(true)

  const [description, setDescription] = useState('')
  const [isDescriptionValid, setIsDescriptionValid] = useState(true)

  const [twitterLink, setTwitterLink] = useState('')
  const [discordLink, setDiscordLink] = useState('')
  const [instagramLink, setInstagramLink] = useState('')
  const [telegramLink, setTelegramLink] = useState('')

  // Input values 
  const onChangeName = (e) => {
    var title = e.target.value;
    setName(title)
    if (title === '') {
      setIsNameValid(false)
    } else {
      setIsNameValid(true)
    }
  }

  const onChangeTwitter = (e) => {
    var val = e.target.value;
    setTwitterLink(val)
  }

  const onChangeDiscord = (e) => {
    var val = e.target.value;
    setDiscordLink(val)
  }

  const onChangeInstagram = (e) => {
    var val = e.target.value;
    setInstagramLink(val)
  }

  const onChangeTelegram = (e) => {
    var val = e.target.value;
    setTelegramLink(val)
  }
  const onChangeDescription = (e) => {
    var desc = e.target.value;
    setDescription(desc)
    if (desc === '') {
      setIsDescriptionValid(false)
    } else {
      setIsDescriptionValid(true)
    }
  }
  const onChangeBanner = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      var files = e.target.files;
      const file = e.target.files[0];

      var filesArray = [].slice.call(files);
      filesArray.forEach((e) => {
        if (
          e.name.search("png") >= 0 ||
          e.name.search("bmp") >= 0 ||
          e.name.search("gif") >= 0 ||
          e.name.search("jpg") >= 0 ||
          e.name.search("jpeg") >= 0 ||
          e.name.search("webp") >= 0
        ) {
          var img = new Image();
          img.src = URL.createObjectURL(file);
          img.onload = function () {
            URL.revokeObjectURL(img.src);
            setBannerImage(file)
            setBannerPreImage(URL.createObjectURL(file))
            // URL.createObjectURL(file)
          }

        } else {
          toast.error("Please select image file!");
        }
      });
    }
  };
  const onChangeAvatar = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      var files = e.target.files;
      const file = e.target.files[0];

      var filesArray = [].slice.call(files);
      filesArray.forEach((e) => {
        if (
          e.name.search("png") >= 0 ||
          e.name.search("bmp") >= 0 ||
          e.name.search("gif") >= 0 ||
          e.name.search("jpg") >= 0 ||
          e.name.search("jpeg") >= 0 ||
          e.name.search("webp") >= 0
        ) {
          var img = new Image();
          img.src = URL.createObjectURL(file);
          img.onload = function () {
            URL.revokeObjectURL(img.src);
            setAvatarImage(file)
            setAvatarPreImage(URL.createObjectURL(file))
          }

        } else {
          toast.error("Please select image file!");
        }
      });
    }
  };
  const removeMainImage = (e) => {
    e.preventDefault();
    setBannerImage("");
  };

  const onValid = () => {
    if (name === '') {
      setIsNameValid(false)
    }
    if (description === '') {
      setIsDescriptionValid(false)
    }
  }

  const [setLoading, setMessage] = useLoader()

  async function submitUpdate() {
    setLoading(true)
    setMessage('Updating profile...')
    onValid();

    if (name === '' || description === '') {
      toast.error("Please enter correct Data");
      setLoading(false)
      return;
    }
    try {
      var avatarurl = '';
      if (!avatarImage) {
        avatarurl = avatarPreImage
      } else {
        const av = await uploadToStorage(avatarImage);
        avatarurl = `https://${av}.ipfs.nftstorage.link`;
      }
      var bannerurl = ''
      if (!bannerImage) {
        bannerurl = bannerPreImage
      } else {
        const ba = await uploadToStorage(bannerImage);
        bannerurl = `https://${ba}.ipfs.nftstorage.link`;
      }

      await updateUserProfile(currentUser?.addr, name, description, avatarurl, bannerurl, twitterLink, discordLink, instagramLink, telegramLink);
      toast.success("Profile updated successfully.");

      setTimeout(() => {
        window.location.reload();
      }, 3000);
    } catch (error) {
      toast.error("Profile updating failed.");
      console.error(error);
    }
    setLoading(false)
  }

  const [userData, setUserData] = useState();

  useEffect(() => {

    async function fetchUserData(addr) {
      try {
        const userProfile = await getUserProfile(addr);
        setUserData(userProfile);

        setAvatarPreImage(userProfile?.avatarImage)
        setBannerPreImage(userProfile?.bannerImage)
        setName(userProfile?.name)

        setDescription(userProfile?.description)
        setTwitterLink(userProfile?.twitter)
        setDiscordLink(userProfile?.discord)
        setInstagramLink(userProfile?.instagram)
        setTelegramLink(userProfile?.telegram)
        // console.log(userProfile)
      } catch (e) {
        console.log(e);
      }
    }

    if (currentUser) {
      fetchUserData(currentUser?.addr)
    }

  }, [currentUser])

  return (
    <div className="edit-profile">
      <GlobalStyles />

      <section className='container no-bottom  top-section'>
        <div className='row'>
          <div className="col-md-12 top-banner"
            style={{ background: `url("${bannerPreImage || userData?.bannerImage || '/img/background/8.jpg'}")` }}
          >
            <div className="d_profile de-flex">
              <div className="de-flex-col ">
                <div className="profile_avatar">
                  <div className="avater-div">
                    <img src={avatarPreImage || userData?.avatarImage || "/img/author/avatar.png"} alt="" className="avatarImage" />

                    <div className="changeAvatar">
                      <div className='btns'>
                        <button className="">
                          <i className="fas fa-camera"></i>
                        </button>
                        <input className="upload_file" id='upload_file' type="file" onChange={onChangeAvatar} />
                      </div>
                    </div>
                  </div>
                  <i className="fa fa-check"></i>
                  <div className="col-12">
                    <div className="profile_name">
                      <div className="col-12">
                        <h4>{userData?.name || name || "No Name"}</h4>
                        <p id="" className="">{userData?.description || ""}</p>
                        <span id="wallet" className="profile_wallet">{currentUser?.addr || ""}
                          <button id="btn_copy" className="btn_copy" title="Copy Text">
                            <img src='/img/clone-copy-document-duplicate-file-icon-9.png' alt="" className="" /></button>
                        </span>

                      </div>
                    </div>
                    <div className="spacer-10"></div>

                  </div>
                </div>
              </div>
            </div>
            <div className="inputBanner">
              <div className='btns'>
                <input type="button" id="get_file" className="btn-main" value="Change Banner" />
                <input className="upload_file" id='upload_file' type="file" onChange={onChangeBanner} />
              </div>
            </div>
            {/* <div className="description">
            <div className="profile_username">{userData?.description || description || ""}</div>
            </div> */}
            <div className='social-links'>

              {
                userData?.twitter &&
                <a target="_blank" rel="noreferrer" href={userData?.twitter || ''} className="">
                  <i className="fab fa-twitter"></i>
                </a>
              }
              {
                userData?.discord && <a target="_blank" rel="noreferrer" href={userData?.discordLink || ''} className="">
                  <i className="fab fa-discord"></i>
                </a>
              }
              {
                userData?.instagram && <a target="_blank" rel="noreferrer" href={userData?.instagram || ''} className="">
                  <i className="fab fa-instagram"></i>
                </a>
              }
              {
                userData?.telegram && <a target="_blank" rel="noreferrer" href={userData?.telegram || ''} className="">
                  <i className="fab fa-telegram"></i>
                </a>
              }
            </div>

            {bannerImage &&
              <div className="remove">
                <button className="removeBtn" onClick={removeMainImage}>
                  <i className="fas fa-times"></i>
                </button>
              </div>}

          </div>
        </div>
      </section>

      <section className='container no-top'>
        <div className="row">
          <div className="col-md-12">
            <form id="form-create-item" className="form-border myForm" action="submitUpdate">
              <div className="field-set">
                <div className="spacer-single"></div>

                <h5>Name</h5>
                <input type="text" name="item_title" id="item_title"
                  className="form-control" placeholder="Enter your name"
                  value={name}
                  onChange={onChangeName}
                  style={{ boxShadow: isNameValid ? '0px 0px 0px red' : '0px 0px 3px red' }}
                />

                <div className="spacer-10"></div>

                <h5>Description</h5>
                <textarea onChange={onChangeDescription} data-autoresize name="item_desc" id="item_desc" className="form-control" placeholder="e.g. 'My Profile'"
                  style={{ boxShadow: isDescriptionValid ? '0px 0px 0px red' : '0px 0px 3px red' }}
                  value={description}
                ></textarea>

                <div className="spacer-10"></div>

                <h5><i className="fab fa-twitter"></i> Twitter</h5>
                <input type="text" className="form-control" onChange={(e) => onChangeTwitter(e)} value={twitterLink} name="twitter" placeholder="Your Twitter Link" />
                <div className="spacer-10"></div>
                <h5><i className="fab fa-discord"></i> Discord</h5>
                <input type="text" className="form-control" onChange={(e) => onChangeDiscord(e)} value={discordLink} name="discord" placeholder="Your Discord Link" />
                <div className="spacer-10"></div>
                <h5><i className="fab fa-instagram"></i> Instagram</h5>
                <input type="text" className="form-control" onChange={(e) => onChangeInstagram(e)} value={instagramLink} name="instagram" placeholder="Your Instagram Link" />
                <div className="spacer-10"></div>
                <h5><i className="fab fa-telegram"></i> Telegram</h5>
                <input type="text" className="form-control" onChange={(e) => onChangeTelegram(e)} value={telegramLink} name="telegram" placeholder="Your Telegram Link" />

                <div className="spacer-10"></div>

                <input type="button" id="submit" className="btn-main" value="Update Profile" onClick={submitUpdate} />
              </div>
            </form>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
export default EditProfile;
