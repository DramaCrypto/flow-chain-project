import React, { useEffect, useState } from "react";
import Footer from '../../components/footer';
import { createGlobalStyle } from 'styled-components';
import { fetchAccountItems } from "src/flow/script.get-account-items";
import { fetchAccountSaleItems } from "src/flow/script.get-account-sale-items";
import ItemList from "../../components/itemList/ItemList";
import { useLocation } from "@reach/router";
import {getUserProfile} from 'src/api/userProfile'
import { Link } from '@reach/router';
import useAppContext from "src/hooks/useAppContext";
import './style.scss'
const GlobalStyles = createGlobalStyle`
  header#myHeader.navbar.white {
    background: #212428;
  }
`;

const Profile = function () {

  const location = useLocation();
  const walletAddress = location.pathname.split('/').pop();
  const { currentUser} = useAppContext();
  const [openMenu, setOpenMenu] = React.useState(false);
  const [openMenu1, setOpenMenu1] = React.useState(true);
  const handleBtnClick = () => {
    setOpenMenu(!openMenu);
    setOpenMenu1(false);
    document.getElementById("Mainbtn").classList.add("active");
    document.getElementById("Mainbtn1").classList.remove("active");
  };
  const handleBtnClick1 = () => {
    setOpenMenu1(!openMenu1);
    setOpenMenu(false);
    document.getElementById("Mainbtn1").classList.add("active");
    document.getElementById("Mainbtn").classList.remove("active");
  };

  const [items, setItems] = useState([]);
  const [saleItems, setSaleItems] = useState([]);
  const [userData, setUserData] = useState();

  useEffect(() => {
    async function fetchItems(addr) {
      try {
        const _items = await fetchAccountItems(addr);
        setItems(_items);
      } catch (e) {
        console.log(e);
      }
    }

    async function fetchSaleItems(addr) {
      try {
        const _items = await fetchAccountSaleItems(addr);
        setSaleItems(_items);
      } catch (e) {
        console.log(e);
      }
    }
    async function fetchUserData(addr) {
      try {
        const userProfile = await getUserProfile(addr);
        setUserData(userProfile);
      } catch (e) {
        console.log(e);
      }
    }

    fetchItems(walletAddress);
    fetchSaleItems(walletAddress);
    fetchUserData(walletAddress)
  }, [walletAddress])

  // console.log(saleItems)
  return (
    <div className="edit-profile">
      <GlobalStyles />
      <section className='container no-bottom top-section'>
        <div className='row'>
          <div className="col-md-12 top-banner"
            style={{background : `url("${userData?.bannerImage || '/img/background/8.jpg'}")`}}
          >
            <div className="d_profile de-flex">
              <div className="de-flex-col">
                <div className="profile_avatar col-lg-12">
                  <div className="avater-div">
                    <img className="avatarImage" src={userData?.avatarImage || "/img/author/avatar.png"} alt="" />
                  </div>
                  <i className="fa fa-check"></i>
                  <div className="col-12">
                    <div className="profile_name">
                      <div className="col-12">
                        <h4>{userData?.name || "No Name"}</h4>
                        <p id="" className="">{userData?.description || ""}</p>
                        <span id="wallet" className="profile_wallet">{walletAddress || ""}
                        <button id="btn_copy" className="btn_copy" title="Copy Text">
                          <img src='/img/clone-copy-document-duplicate-file-icon-9.png' alt="" className="" /></button></span>
                        {/* <button id="btn_copy" title="Copy Text">Copy</button> */}
                      </div>
                    </div>
                    <div className="spacer-10"></div>
                    
                  </div>
                  
                </div>
              </div>
            </div>
            {/* <div className="description">
            <div className="profile_username">{userData?.description || ""}</div>
            </div> */}
            <div className='social-links'>
                
                      {
                        userData?.twitter && 
                          <a target="_blank" rel="noreferrer" href={userData?.twitter || ''} className="">
                              <i className="fab fa-twitter"></i>
                          </a>
                      }
                      {
                          userData?.discord && <a target="_blank" rel="noreferrer" href={userData?.discord || ''} className="">
                              <i className="fab fa-discord"></i>
                          </a>
                      }
                      {
                          userData?.instagram &&  <a target="_blank" rel="noreferrer" href={userData?.instagram || ''} className="">
                              <i className="fab fa-instagram"></i>
                          </a>
                      }
                      {
                          userData?.telegram &&  <a target="_blank" rel="noreferrer" href={userData?.telegram || ''} className="">
                          <i className="fab fa-telegram"></i>
                      </a>
                      }
            </div>
            <div className="editLink">
              {userData?.walletAddress.includes(currentUser?.addr) &&
                <Link className="btn-main ml-5" to={`/edit-profile`} >Edit</Link>
              }
            </div>
          </div>
        </div>
      </section>

      <section className='container no-top'>
        <div className='row'>
          <div className='col-lg-12'>
            <div className="items_filter">
              <ul className="de_nav text-left">
                <li id='Mainbtn1' className="active"><span onClick={handleBtnClick1}>Collected</span></li>
                <li id='Mainbtn' className=""><span onClick={handleBtnClick}>On Sale</span></li>
                
              </ul>
            </div>
          </div>
        </div>
        {openMenu && (
          <div id='zero1' className='onStep fadeIn'>
            <ItemList nfts={items} isSale saleItems={saleItems} user = {userData}/>
          </div>
        )}
        {openMenu1 && (
          <div id='zero2' className='onStep fadeIn'>
            <ItemList nfts={items}  user = {userData}/>
          </div>
        )}
        
      </section>


      <Footer />
    </div>
  );
}
export default Profile;