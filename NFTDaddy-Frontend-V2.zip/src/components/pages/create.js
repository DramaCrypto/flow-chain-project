import React, { useState, useEffect } from "react";
import { uploadToStorage } from "src/util/nft-storage";
import UploadFile from "../components/uploadFile/UploadFile";
import toast from 'react-hot-toast';
import Footer from '../components/footer';
import NFTCard from "../components/cards/nftCard/NFTCard";
import DateTimePickerField from "../components/DateTimePicker";
import moment from 'moment';
import { useLoader } from 'src/hooks/useLoader'
import { mintAndList } from "src/flow/tx.mint-and-list";
import { getUserProfile } from 'src/api/userProfile'
import useAppContext from "src/hooks/useAppContext";
export default function Createpage() {
  const [fileSrc, setFileSrc] = useState(null)
  const [fileType, setFileType] = useState(null)
  const [previewURL, setPreviewURL] = useState(null)

  const [name, setName] = useState('')
  const [isNameValid, setIsNameValid] = useState(true)

  const [description, setDescription] = useState('')
  const [isDescriptionValid, setIsDescriptionValid] = useState(true)

  const [saleItemPrice, setSaleItemPrice] = useState(0)
  const [isPriceValid, setIsPriceValid] = useState(true)

  const [royaltyCut, setRoyaltyCut] = useState(0)
  const [isRoyaltyValid, setIsRoyaltyValid] = useState(true)

  const [expireTimestamp, setExpireTimestamp] = useState(0)
  const [isTimesValid, setIsTimesValid] = useState(true)

  // Input values 
  const onChangeName = (e) => {
    var title = e.target.value;
    setName(title)
    if (title === '') {
      setIsNameValid(false)
    } else {
      setIsNameValid(true)
    }
  }
  const onChangeDescription = (e) => {
    var desc = e.target.value;
    setDescription(desc)
    if (desc === '') {
      setIsDescriptionValid(false)
    } else {
      setIsDescriptionValid(true)
    }
  }
  const onChangeRoyaltyCut = (e) => {
    var royalCut = parseFloat(e.target.value);
    if (royalCut >= 100) {
      toast.error("Royalty should be lower than 100%");
      setIsRoyaltyValid(false)
      return;
    }
    setRoyaltyCut(royalCut / 100)
    if (royalCut === 0) {
      setIsRoyaltyValid(false)
    } else {
      setIsRoyaltyValid(true)
    }
  }
  const onChangeExpireTimestamp = (e) => {
    var time = e;
    const d = moment(time).valueOf();
    setExpireTimestamp(d / 1000)
    if (d < Date.now()) {
      toast.error("ExpireTimes should be over than currrent time!");
    }
    if (d === 0 || d < Date.now()) {
      setIsTimesValid(false)
    } else {
      setIsTimesValid(true)
    }
  }
  const onChangePrice = (e) => {
    var price = parseFloat(e.target.value);
    setSaleItemPrice(price)
    if (price === 0) {
      setIsPriceValid(false)
    } else {
      setIsPriceValid(true)
    }
  }
  const onValid = () => {
    if (name === '') {
      setIsNameValid(false)
    }
    if (description === '') {
      setIsDescriptionValid(false)
    }
    if (saleItemPrice === 0) {
      setIsPriceValid(false)
    }
    if (royaltyCut === 0) {
      setIsRoyaltyValid(false)
    }
    if (expireTimestamp === 0) {
      setIsTimesValid(false)
    }
  }

  const [setLoading, setMessage] = useLoader()

  async function submitNFTMint() {
    setLoading(true)
    setMessage('Creating New Item...')
    onValid();
    if (!fileSrc) {
      toast.error("Please select file");
      setLoading(false)
      return;
    }
    if (name === ''
      || description === ''
      || saleItemPrice === 0
      || royaltyCut === 0
      || expireTimestamp === 0) {
      toast.error("Please enter correct Data");
      setLoading(false)
      return;
    }

    const cid = await uploadToStorage(fileSrc);
    const thumbnail = `https://${cid}.ipfs.nftstorage.link`;
    try {
      const onSuccess = () => {
        toast.success("NFT minted and listed successfully.");
        setTimeout(() => {
          window.location.replace("/explore");
        }, 3000);
      };

      const onError = () => {
        toast.error("NFT minting failed.");
      }

      await mintAndList(name, description, thumbnail, royaltyCut, expireTimestamp, saleItemPrice, {
        onError: onError,
        onSuccess: onSuccess
      });
    } catch (error) {
      toast.error("NFT minting failed.");
      console.error(error);
    }
    setLoading(false)
  }
  const { currentUser } = useAppContext();
  const [userData, setUserData] = useState();

  useEffect(() => {

    async function fetchUserData(addr) {
      try {
        const userProfile = await getUserProfile(addr);
        setUserData(userProfile);
      } catch (e) {
        console.log(e);
      }
    }
    if (currentUser) {
      fetchUserData(currentUser?.addr)
    }
  }, [currentUser])
  return (
    <div>
      <section className='container'>
        <div className="row">
          <div className="col-lg-7 offset-lg-1 mb-5">
            <form id="form-create-item" className="form-border" action="submitNFTMint">
              <div className="field-set">
                <h5>Upload file</h5>
                <UploadFile
                  setFileSrc={setFileSrc}
                  setFileType={setFileType}
                  setPreviewURL={setPreviewURL}
                />

                <div className="spacer-single"></div>

                <h5>Title</h5>
                <input type="text" name="item_title" id="item_title"
                  className="form-control" placeholder="e.g. 'Crypto Funk"
                  onChange={onChangeName}
                  style={{ boxShadow: isNameValid ? '0px 0px 0px red' : '0px 0px 3px red' }}
                />

                <div className="spacer-10"></div>

                <h5>Description</h5>
                <textarea onChange={onChangeDescription} data-autoresize name="item_desc" id="item_desc" className="form-control" placeholder="e.g. 'This is very limited item'"
                  style={{ boxShadow: isDescriptionValid ? '0px 0px 0px red' : '0px 0px 3px red' }}
                ></textarea>

                <div className="spacer-10"></div>

                <h5>Price</h5>
                <input type="text" onChange={onChangePrice} name="item_price" id="item_price" className="form-control" placeholder="enter price for one item (ETH)"
                  style={{ boxShadow: isPriceValid ? '0px 0px 0px red' : '0px 0px 3px red' }}
                />

                <div className="spacer-10"></div>
                <h5>Expire Listing Time</h5>
                <DateTimePickerField
                  value={expireTimestamp * 1000}
                  label=""
                  onChange={e => onChangeExpireTimestamp(e)}
                  classNAME={isTimesValid ? '' : 'not-valid'}
                />
                <div className="spacer-10"></div>
                <div className="spacer-10"></div>

                <h5>Royalties</h5>
                <input type="text" onChange={onChangeRoyaltyCut} name="item_royalties" id="item_royalties" className="form-control" placeholder="suggested: 0, 10%, 20%, 30%. Maximum is 70%"
                  style={{ boxShadow: isRoyaltyValid ? '0px 0px 0px red' : '0px 0px 3px red' }}
                />

                <div className="spacer-10"></div>

                <input type="button" id="submit" className="btn-main" value="Create Item" onClick={submitNFTMint} />
              </div>
            </form>
          </div>

          <div className="col-lg-3 col-sm-6 col-xs-12">
            <h5>Preview item</h5>
            <NFTCard
              name={name}
              price={saleItemPrice}
              fileType={fileType}
              previewURL={previewURL}
              expireTimestamp={expireTimestamp}
              isPreviewNFT
              userData = {userData}
            />
          </div>
        </div>
      </section>
      <Footer />
      {/* <Loader isLoading={isProcessing} label = {'Please wait ...'}/> */}
    </div>
  );
}