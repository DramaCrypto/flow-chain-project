import React, { useEffect, useState } from 'react';
import Footer from '../../components/footer';
import {getNFTEvents} from 'src/api/nftEvent'
import {getUserList} from 'src/api/userProfile'
import { createGlobalStyle } from 'styled-components';
import moment from 'moment'
import './active.scss'
const GlobalStyles = createGlobalStyle`
  header#myHeader.navbar.white {
    background: #212428;
  }
`;

const Activity= function() {

const [openMenu, setOpenMenu] = React.useState(true);
const [openMenu1, setOpenMenu1] = React.useState(false);
const [openMenu2, setOpenMenu2] = React.useState(false);
const [openMenu3, setOpenMenu3] = React.useState(false);
const [openMenu4, setOpenMenu4] = React.useState(false);
const handleBtnClick = () => {
  setOpenMenu(!openMenu);
  setOpenMenu1(false);
  setOpenMenu2(false);
  setOpenMenu3(false);
  setOpenMenu4(false);
  document.getElementById("follow").classList.remove("active");
  document.getElementById("sale").classList.remove("active");
  document.getElementById("offer").classList.remove("active");
  document.getElementById("like").classList.remove("active");
};
const handleBtnClick1 = () => {
  setOpenMenu1(!openMenu1);
  setOpenMenu2(false);
  setOpenMenu(false);
  setOpenMenu3(false);
  setOpenMenu4(false);
  document.getElementById("follow").classList.add("active");
  document.getElementById("sale").classList.remove("active");
  document.getElementById("offer").classList.remove("active");
  document.getElementById("like").classList.remove("active");
};
const handleBtnClick2 = () => {
  setOpenMenu2(!openMenu2);
  setOpenMenu(false);
  setOpenMenu1(false);
  setOpenMenu3(false);
  setOpenMenu4(false);
  document.getElementById("follow").classList.remove("active");
  document.getElementById("sale").classList.add("active");
  document.getElementById("offer").classList.remove("active");
  document.getElementById("like").classList.remove("active");
};
const handleBtnClick3 = () => {
  setOpenMenu3(!openMenu3);
  setOpenMenu(false);
  setOpenMenu1(false);
  setOpenMenu2(false);
  setOpenMenu4(false);
  document.getElementById("follow").classList.remove("active");
  document.getElementById("sale").classList.remove("active");
  document.getElementById("offer").classList.remove("active");
  document.getElementById("like").classList.add("active");
};
const handleBtnClick4 = () => {
  setOpenMenu4(!openMenu4);
  setOpenMenu(false);
  setOpenMenu1(false);
  setOpenMenu3(false);
  setOpenMenu2(false);
  document.getElementById("follow").classList.remove("active");
  document.getElementById("sale").classList.remove("active");
  document.getElementById("offer").classList.add("active");
  document.getElementById("like").classList.remove("active");
};
const [activityList, setActivityList] = useState([]);
const [userList, setUserList] = useState([]);

useEffect(() => {


  async function fetchSellers() {
    try {
      const _sellers = await getUserList()
      setUserList(_sellers);
    } catch (e) {
      console.log(e);
    }
  }
  fetchSellers();
  }, [])
  useEffect(() => {
    async function fetchActivity( ) {
      try {
        const _activity = await getNFTEvents("", "")
        setActivityList(_activity)
      } catch (e) {
        console.log(e);
      }
    }
    fetchActivity()
  }, [])
return (
<div className='active'>
<GlobalStyles/>
  <section className='container'>
  <div className="spacer-10"></div>
    <div className='row'>

    <div className="col-md-8">

    {openMenu && (  
    <ul className="activity-list">
      {activityList &&
        activityList.map((d, k)=>{
          const user = userList.find(user=> user?.walletAddress.includes(d?.owner))
          // console.log(d?.eventType, user, d?.owner)
          var formatted = moment(parseInt(d?.eventTime* 1000)).format("YYYY/MM/DD hh:MM:ss");
            return(
              <li className="act-row" key = {k}>
                <img className="lazy" src={d?.thumbnail || "/img/author/avatar.png"} alt=""/>
                <div className="act_list_text">
                    <h4>{user?.name || user?.walletAddress || 'No Name'}</h4>
                    {d?.eventType} <span className='color go-profile' onClick={()=> window.open(`/profile/${user?.owner}`, "_self")}>by {user?.name || user?.walletAddress || 'No Name'}</span>
                    <span className="act_list_date">
                        {formatted}
                    </span>
                </div>

                <div className='active-icon'>
                  {d?.eventType === 'MINT' && <i className="fas fa-coins"></i>}
                  {d?.eventType === 'LIST' && <i className="fas fa-th-list"></i>}
                  {d?.eventType === 'DELIST' && <i className="fas fa-list-alt"></i>}
                  {d?.eventType === 'SELL' && <i className="fa fa-check"></i>}
                </div>
              </li>
            )
          })}
      </ul>
      )}

    {openMenu1 && (  
    <ul className="activity-list">
     {activityList &&
        activityList.map((d, k)=>{
          const user = userList.find(user=> user?.walletAddress.includes(d?.owner))
          // console.log(d?.eventType, user, d?.owner)
          var formatted = moment(parseInt(d?.eventTime* 1000)).format("YYYY/MM/DD hh:MM:ss");
          if (d?.eventType === 'SELL'){
            return(
              <li className="act-row" key = {k}>
                <img className="lazy" src={d?.thumbnail || "/img/author/avatar.png"} alt=""/>
                <div className="act_list_text">
                    <h4>{user?.name || 'No Name'}</h4>
                    {d?.eventType} <span className='color'>by {user?.name || 'No Name'}</span>
                    <span className="act_list_date">
                        {formatted}
                    </span>
                </div>
                <div className='active-icon'>
                  {d?.eventType === 'MINT' && <i className="fas fa-coins"></i>}
                  {d?.eventType === 'LIST' && <i className="fas fa-th-list"></i>}
                  {d?.eventType === 'DELIST' && <i className="fas fa-list-alt"></i>}
                  {d?.eventType === 'SELL' && <i className="fa fa-check"></i>}
                </div>
              </li>
            )
          }
          else return null;
          })}
    </ul>
    )}

    {openMenu2 && (  
    <ul className="activity-list">
      {activityList &&
        activityList.map((d, k)=>{
          const user = userList.find(user=> user?.walletAddress.includes(d?.owner))
          // console.log(d?.eventType, user, d?.owner)
          var formatted = moment(parseInt(d?.eventTime* 1000)).format("YYYY/MM/DD hh:MM:ss");
          if (d?.eventType === 'MINT'){
            return(
              <li className="act-row" key = {k}>
                <img className="lazy" src={d?.thumbnail || "/img/author/avatar.png"} alt=""/>
                <div className="act_list_text">
                    <h4>{user?.name || 'No Name'}</h4>
                    {d?.eventType} <span className='color'>by {user?.name || 'No Name'}</span>
                    <span className="act_list_date">
                        {formatted}
                    </span>
                </div>
                <div className='active-icon'>
                  {d?.eventType === 'MINT' && <i className="fas fa-coins"></i>}
                  {d?.eventType === 'LIST' && <i className="fas fa-th-list"></i>}
                  {d?.eventType === 'DELIST' && <i className="fas fa-list-alt"></i>}
                  {d?.eventType === 'SELL' && <i className="fa fa-check"></i>}
                </div>
              </li>
            )
          }
          else return null;
          })}
    </ul>
    )}

    {openMenu3 && ( 
      <ul className="activity-list">
       {activityList &&
        activityList.map((d, k)=>{
          const user = userList.find(user=> user?.walletAddress.includes(d?.owner))
          // console.log(d?.eventType, user, d?.owner)
          var formatted = moment(parseInt(d?.eventTime* 1000)).format("dd.mm.yyyy hh:MM:ss");
          if (d?.eventType === 'LIST'){
            return(
              <li className="act-row" key = {k}>
                <img className="lazy" src={d?.thumbnail || "/img/author/avatar.png"} alt=""/>
                <div className="act_list_text">
                    <h4>{user?.name || 'No Name'}</h4>
                    {d?.eventType} <span className='color'>by {user?.name || 'No Name'}</span>
                    <span className="act_list_date">
                        {formatted}
                    </span>
                </div>
                <div className='active-icon'>
                  {d?.eventType === 'MINT' && <i className="fas fa-coins"></i>}
                  {d?.eventType === 'LIST' && <i className="fas fa-th-list"></i>}
                  {d?.eventType === 'DELIST' && <i className="fas fa-list-alt"></i>}
                  {d?.eventType === 'SELL' && <i className="fa fa-check"></i>}
                </div>
              </li>
            )
          }
          else return null;
          })}
      </ul>
    )}

    {openMenu4 && ( 
      <ul className="activity-list">
        {activityList &&
        activityList.map((d, k)=>{
          const user = userList.find(user=> user?.walletAddress.includes(d?.owner))
          // console.log(d?.eventType, user, d?.owner)
          var formatted = moment(parseInt(d?.eventTime* 1000)).format("dd.mm.yyyy hh:MM:ss");
          if (d?.eventType === 'DELIST'){
            return(
              <li className="act-row" key = {k}>
                <img className="lazy" src={d?.thumbnail || "/img/author/avatar.png"} alt=""/>
                <div className="act_list_text">
                    <h4>{user?.name || 'No Name'}</h4>
                    {d?.eventType} <span className='color'>by {user?.name || 'No Name'}</span>
                    <span className="act_list_date">
                        {formatted}
                    </span>
                </div>
                <div className='active-icon'>
                  {d?.eventType === 'MINT' && <i className="fas fa-coins"></i>}
                  {d?.eventType === 'LIST' && <i className="fas fa-th-list"></i>}
                  {d?.eventType === 'DELIST' && <i className="fas fa-list-alt"></i>}
                  {d?.eventType === 'SELL' && <i className="fa fa-check"></i>}
                </div>
              </li>
            )
          }
          else return null;
          })}
      </ul>
    )}
    </div>
      <div className="col-md-4">
          <span className="filter__l">Filter</span>
          <span className="filter__r" onClick={handleBtnClick}>Reset</span>
          <div className="spacer-half"></div>
          <div className="clearfix"></div>
          <ul className="activity-filter">
              <li id='sale' className="filter_by_sales" onClick={handleBtnClick2}><i className="fas fa-coins"></i>MINT</li>
              <li id='like' className="filter_by_likes" onClick={handleBtnClick3}><i className="fas fa-th-list"></i>LIST</li>
              <li id='offer' className="filter_by_offers" onClick={handleBtnClick4}><i className="fas fa-list-alt"></i>DELIST</li>
              <li id='follow' className="filter_by_followings" onClick={handleBtnClick1}><i className="fa fa-check"></i>SELL</li>
          </ul>
      </div>
    </div>
  </section>

  <Footer />
</div>

);
}

export default Activity;