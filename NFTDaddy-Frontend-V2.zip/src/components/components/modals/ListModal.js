import './listModal.scss'
import Bounce  from 'react-reveal/Bounce';
import { useEffect, useState } from 'react';
import DateTimePickerField from "../DateTimePicker";
import toast from 'react-hot-toast';
import moment from 'moment';

const ListModal = (props) => {
    const {showModal, setShowModal, funcListing} = props
    const [isStart, setIsStart] = useState(false)
    useEffect(() => {
        if(showModal)
        {
            setTimeout(() => {
                setIsStart(true)
            }, 100)
        }
        
    }, [setIsStart,  showModal]);
    const onClose = ()=>{
        setIsStart(false)
        setTimeout(() => {
            setShowModal(false);
        }, 800)
    }

    const [salePrice, setSalePrice] = useState(0)
    const [isPriceValid, setIsPriceValid] = useState(true)

    const [expireTimestamp, setExpireTimestamp] = useState(0)
    const [isTimesValid, setIsTimesValid] = useState(true)

    const onChangePrice = (e) => {
        var price = parseFloat(e.target.value);
        setSalePrice(price)
        if (price === 0) {
          setIsPriceValid(false)
        } else {
          setIsPriceValid(true)
        }
    }

    const onChangeExpireTimestamp = (e) => {
        var time = e;
        const d = moment(time).valueOf();
        setExpireTimestamp(d / 1000)
        if (d < Date.now()) {
          toast.error("ExpireTimes should be over than currrent time!");
        }
        if (d === 0 || d < Date.now()) {
          setIsTimesValid(false)
        } else {
          setIsTimesValid(true)
        }
    }

    const onValid = () => {
        if (salePrice === 0) {
          setIsPriceValid(false)
        }
        if (expireTimestamp === 0) {
          setIsTimesValid(false)
        }
      }
    const onConfrim=()=>{
        onValid()
        if (salePrice === 0
            || expireTimestamp === 0) {
            toast.error("Please enter correct Data");
            return;
        }
      funcListing(salePrice, expireTimestamp)
      onClose()
    }
    return (
        <div className={showModal === true ? "listModal active" : "listModal"}>
            <Bounce opposite when={isStart}>
            <div className="modelContent">
                <div className="connectWalletHeader">
                    <h1 className="connectWalletTitle">List On Sale</h1>
                    <button className="connectModalCloseButton" onClick={onClose}><i className="fas fa-times"></i></button>
                </div>
                <div className="connectWalletWrapper">
                <div className="spacer-10"></div>
                <h5>Price</h5>
                <input type="text" onChange={onChangePrice} name="item_price" id="item_price" className="form-control" placeholder="enter price for one item (ETH)"
                  style={{ boxShadow: isPriceValid ? '0px 0px 0px red' : '0px 0px 3px red' }}
                />

                <div className="spacer-10"></div>
                <h5>Expire Listing Time</h5>
                <DateTimePickerField
                  value={expireTimestamp * 1000}
                  label=""
                  onChange={e => onChangeExpireTimestamp(e)}
                  classNAME={isTimesValid ? '' : 'not-valid'}
                />
                <div className="spacer-10"></div>
                <div className="spacer-10"></div>
                <div className="spacer-10"></div>
                <button className="btn-main out-line"
                    onClick={onConfrim}
                >Confirm</button>

                </div>
            </div>
            </Bounce>

        </div>
    )
}
export default ListModal;