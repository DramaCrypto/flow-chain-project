import React, { useEffect } from "react";
import { useState } from "react";
import styled from "styled-components";
import Clock from "../Clock";

const Outer = styled.div`
  display: flex;
  justify-content: center;
  align-content: center;
  align-items: center;
  overflow: hidden;
  border-radius: 8px;
`;

export default function ItemList(props) {

    const { nfts, isSale, saleItems, user } = props;

    const [myNFT, setMyNFT] = useState([])
    const [height, setHeight] = useState(0)
    const onImgLoad = ({ target: img }) => {
        let currentHeight = height;
        if (currentHeight < img.offsetHeight) {
            setHeight(img.offsetHeight)
        }
    }

    useEffect(() => {
        if (isSale) {
            
            if( Object.values(saleItems).length>0){
                
                var filteredNFT = nfts.filter((nft) =>{
                    // console.log(nft.id, Object.values(saleItems).find(item=>nft.id === item.nftID))
                    return  Object.values(saleItems).find(item=>nft.id === item.nftID)
                   })
                // var filteredNFT = nfts.filter((nft) =>
                // Object.values(saleItems).includes(nft.id.toString()))
                // console.log(filteredNFT)
                setMyNFT(filteredNFT)
            }else{
                setMyNFT([])
            }
            
        } else {
            setMyNFT(nfts)
            
        }
    }, [isSale, nfts, setMyNFT, saleItems])

    return (
        <div className='row'>
            {myNFT &&
                (myNFT.map((nft, index) => {
                    if (isSale === true) {
                        var timeStamp = saleItems[nft.id]?.expiry.length > 10 ? saleItems[nft.id]?.expiry / 1000 : saleItems[nft.id]?.expiry
                        var price = parseFloat(saleItems[nft.id]?.salePrice).toFixed(2)
                    }
                    return (

                        <div key={index} className="d-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                            <div className="nft__item">
                                {isSale && timeStamp * 1000 > Date.now() && 
                                    <div className="de_countdown">
                                        <Clock deadline={timeStamp || 0} />
                                    </div>}
                                <div className="author_list_pp">
                                    <span onClick={()=> window.open(`/profile/${nft?.owner}`, "_self")}>
                                        <img className="lazy" src={user?.avatarImage || '/img/author/avatar.png'} alt="" />
                                        <i className="fa fa-check"></i>
                                    </span>
                                </div>
                                <div className="nft__item_wrap"
                                    style={{ height: `${height}px`,
                                    minHeight : 266,
                                    background : '#ffffff11', borderRadius: 8
                                }}
                                >
                                    <Outer>
                                        <span onClick={()=> window.open(`/ItemDetail/${nft?.id}`, "_self")}>
                                            <img onLoad={onImgLoad} src={nft?.thumbnail} className="lazy nft__item_preview" alt="" />
                                        </span>
                                    </Outer>
                                </div>
                                <div className="nft__item_info">
                                    <span onClick={()=> window.open(`/profile/${nft?.owner}`, "_self")}>
                                        <h4>{nft?.name}</h4>
                                    </span>
                                    {isSale &&
                                        <div className="nft__item_price">
                                            {price} FLOW
                                        </div>}
                                    <div className="nft__item_like">
                                        <i className="fa fa-heart"></i><span>{0}</span>
                                    </div>
                                </div>
                            </div>
                        </div>)
                }))}

        </div>
    );
}