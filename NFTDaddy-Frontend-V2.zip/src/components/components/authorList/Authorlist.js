import React from 'react';
import './authorList.scss'
const Authorlist= (props) => {
    const {sellerList} = props
    return (

    <div className='authorList'>
        <ol className="author_list">

            {sellerList && 
            sellerList.map((d, k)=>(
                <li key = {k}>                                    
                    <div className="author_list_pp">
                        <span onClick={()=> window.open(`/profile/${d?.walletAddress}`, "_self")}>
                            <img className="lazy" src={d?.avatarImage || "/img/author/avatar.png"} alt=""/>
                            <i className="fa fa-check"></i>
                        </span>
                    </div>                                    
                    <div className="author_list_info">
                        <span onClick={()=> window.open("", "_self")}>{d?.name || d?.walletAddress || '-'}</span>
                        <span className="bot">{d.soldAmount} FLOW</span>
                    </div>
                </li>
            ))}
        
        </ol>
    </div>
    );
}
export default Authorlist;