//@ ts-check
import { useState } from "react";
import './uploadFile.scss'
import ReactPlayer from "react-player";
export default function UploadFile(props) {
    const { setFileSrc, setFileType, setPreviewURL } = props; //sizeType- 0:logo(200*200), 1:featured(350*350), 2:banner(1400*400)
    
    const [mainFile, setMainFile] = useState(null);
    const [isShowVideo, showVideo] = useState(false);
    const [isPlaying, setIsPlaying] = useState(true);
  
    const onChangeMainFile = (e) => {
      if (e.target.files && e.target.files.length > 0) {
        var files = e.target.files;
        const file = e.target.files[0];
        
        var filesArray = [].slice.call(files);
        filesArray.forEach((e) => {
          if (
            e.name.search("avi") >= 0 ||
            e.name.search("mpg") >= 0 ||
            e.name.search("m4v") >= 0 ||
            e.name.search("mp4") >= 0
          ) {
            setMainFile(file);
            setFileType("video");
            setFileSrc(file);
            showVideo(true);
          }
          if (e.name.search("mp3") >= 0) {
            setMainFile(file);
            setFileType("audio");
            setFileSrc(file);
            showVideo(true);
          }
          if (
            e.name.search("png") >= 0 ||
            e.name.search("bmp") >= 0 ||
            e.name.search("gif") >= 0 ||
            e.name.search("jpg") >= 0 ||
            e.name.search("jpeg") >= 0 ||
            e.name.search("webp") >= 0
          ) {
            var img = new Image();
            img.src = URL.createObjectURL(file);
            img.onload = function(){
              URL.revokeObjectURL(img.src);
              setMainFile(file);
              setPreviewURL(URL.createObjectURL(file));
              setFileType("image");
              setFileSrc(file);
              showVideo(false);
            }
            
          }
        });
      }
    };
  
    const removeMainImage = (e) => {
      e.preventDefault();
      setMainFile("");
      setFileType("");
      setFileSrc(null);
      setIsPlaying(true);
    };

  return (
    <div className="d-create-file uploadFile">
        <div 
            style={{opacity : mainFile ? 0 : 1}}
        >
            <p id="file_name">PNG, JPG, GIF, WEBP or MP4. Max 200mb.</p>
            <p key="{index}">{mainFile?.name || ''}</p>
            
            <div className='browse'>
                <input type="button" id="get_file" className="btn-main" value="Browse" />
                <input id='upload_file' type="file" onChange={onChangeMainFile} />
            </div>
        </div>
        {mainFile && (
            <div className="rbFile">
              <span className={"removeImg"} onClick={removeMainImage}>
                &times;
              </span>
              {isShowVideo ? (
                <>
                  <ReactPlayer
                    width="100%"
                    style={{ position: "absolute" }}
                    height="calc(100%)"
                    url={URL.createObjectURL(mainFile)}
                    playing={isPlaying}
                    controls
                  />
                  <div className="video-change" onClick={onChangeMainFile}>
                    Change
                  </div>
                </>
              ) : (
                <img
                  src={URL.createObjectURL(mainFile)}
                  width={300}
                  height={200}
                  alt=""
                />
                
              )}
            </div>
          )}
    </div>
  )
}
