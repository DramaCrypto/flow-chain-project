import React, { useEffect, useState } from "react";
import Clock from "./Clock";



export default function ColumnNewThreeCol(props) {
    const {nftList, userList, sort} = props

    const [nfts, setNfts] = useState([])
    const [height, setHeight] = useState()
    
    useEffect(() => {
        if(sort === 0){
            const sorted = nftList.sort((a, b) => {
                return a.salePrice - b.salePrice;
            });
            setNfts(sorted.slice(0,6));
        }else if(sort === 1){
            const sorted = nftList.sort((a, b) => {
                return b.salePrice - a.salePrice;
            });
            setNfts(sorted.slice(0,6));
        }else if(sort === 3){
            const sorted = nftList.sort((a, b) => {
                return a.listedTime - b.listedTime;
            });
            setNfts(sorted.slice(0,6));
        }else if(sort === 2){
            const sorted = nftList.sort((a, b) => {
                return b.listedTime - a.listedTime;
            });
            setNfts(sorted.slice(0,6));
        }else if(sort === 5){
            const sorted = nftList.sort((a, b) => {
                return a.mintedTime - b.mintedTime;
            });
            setNfts(sorted.slice(0,6));
        }else if(sort === 4){
            const sorted = nftList.sort((a, b) => {
                return b.mintedTime - a.mintedTime;
            });
            setNfts(sorted.slice(0,6));
        }else{
            setNfts(nftList.slice(0,6));
        }
        setNfts(nftList.slice(0,6));
      }, [nftList, sort])

    const loadMore = () => {
        let nftState = nfts
        let start = nftState.length
        let end = nftState.length+6
        setNfts([...nftState, ...nftList.slice(start, end)])
    }

    const onImgLoad=({target:img})=>{
        let currentHeight = height;
        if(currentHeight < img.offsetHeight) {
            setHeight(img.offsetHeight)
        }
    }
    

 return (
    <div className='row'>
        {nfts && 
            nfts.map( (nft, index) => {
                const user = userList?.find(user=>user?.walletAddress.includes(nft?.owner))
            return (
            <div key={index} className="d-item col-lg-4 col-md-6 col-sm-6 col-xs-12 mb-4">
                <div className="nft__item m-0">
                    {(nft?.expiry.toString().length > 10 ? nft?.expiry / 1000 : nft?.expiry) * 1000 > Date.now() && 
                        <div className="de_countdown">
                            <Clock deadline={nft?.expiry.toString().length > 10 ? nft?.expiry / 1000 : nft?.expiry} />
                        </div>}
                    <div className="author_list_pp">
                        <span onClick={()=> window.open(`/profile/${nft?.owner}`, "_self")}>                                    
                            <img className="lazy" src={user?.avatarImage || "/img/author/avatar.png"} alt=""/>
                            <i className="fa fa-check"></i>
                        </span>
                    </div>
                    <div className="nft__item_wrap" 
                            style={{ height: `${height}px`,
                                minHeight : 266,
                                maxHeight : 266,
                                background : '#ffffff11', borderRadius: 8,
                                overflow : 'hidden'

                            }}
                    
                        >
                        <span onClick={()=> window.open(`/ItemDetail/${nft?.nftID}`, "_self")}>
                            <img onLoad={onImgLoad} src={nft?.thumbnail} className="lazy nft__item_preview" alt=""
                           />
                        </span>
                    </div>
                    <div className="nft__item_info">
                        <span onClick={()=> window.open(`/profile/${nft?.owner}`, "_self")}>
                            <h4>{nft?.name}</h4>
                        </span>
                        <div className="nft__item_price">
                            {nft?.salePrice}<span> FLOW</span>
                        </div>
                        <div className="nft__item_action">
                            {nft?.listed ? 
                                <button className="btn-main">Buy Now</button>:
                                <span>Not Listed</span>
                            }
                        </div>
                        <div className="nft__item_like">
                            <i className="fa fa-heart"></i><span>{0}</span>
                        </div>                            
                    </div> 
                </div>
            </div>  
        )})}
        { nfts.length !== nftList.length &&
            <div className='col-lg-12'>
                <div className="spacer-single"></div>
                <span onClick={() => loadMore()} className="btn-main lead m-auto">Load More</span>
            </div>
        }
    </div>              
    );
}