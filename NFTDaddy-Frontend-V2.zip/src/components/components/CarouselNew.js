import React, { Component, useEffect, useState } from "react";
import Slider from "react-slick";
import styled from "styled-components";
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Clock from "./Clock";
import {getUserList} from 'src/api/userProfile'
const Outer = styled.div`
  display: flex;
  justify-content: center;
  align-content: center;
  align-items: center;
  height: 260px;
  overflow: hidden;
  border-radius: 8px;
`;



class CustomSlide extends Component {
  render() {
    const { index, ...props } = this.props;
    return (
      <div {...props}></div>
    );
  }
}

export default function CarouselNew (props) {
  const {nftList} = props
    var settings = {
      infinite: false,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 1,
      initialSlide: 0,
      adaptiveHeight: 300,
      responsive: [
        {
          breakpoint: 1900,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 1,
            infinite: true
          }
        },
        {
          breakpoint: 1600,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 1,
            infinite: true
          }
        },
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            infinite: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: true
          }
        }
      ]
    };
    const [userList, setUserList] = useState();

    useEffect(() => {
      async function fetchUserData() {
        try {
          const users = await getUserList();
          setUserList(users);
        } catch (e) {
          console.log(e);
        }
      }
  
      fetchUserData()
    }, [])
    return (
        <div className='nft'>
          <Slider {...settings}>
            {nftList && 
            nftList.map((d, k)=>{
              const user = userList?.find(user=>user?.walletAddress.includes(d?.owner))
              return(
                d?.listed === true &&
              <CustomSlide className='itm' index={1} key = {k}>
              <div className="d-item">
                <div className="nft__item">
                   {(d?.expiry.toString().length > 10 ? d?.expiry / 1000 : d?.expiry) * 1000 > Date.now() &&
                    <div className="de_countdown">
                    
                      <Clock deadline={d?.expiry.toString().length > 10 ? d?.expiry / 1000 : d?.expiry} />
                    
                    </div>}
                    <div className="author_list_pp">
                        <span onClick={()=> window.open(`/profile/${d?.owner}`, "_self")}>                                    
                            <img className="lazy" src={user?.avatarImage || "/img/author/avatar.png"} alt=""/>
                            <i className="fa fa-check"></i>
                            
                        </span>
                    </div>
                    <div className="nft__item_wrap">
                      <Outer>
                        <span onClick={()=> window.open(`/ItemDetail/${d?.nftID}`, "_self")}>
                            <img src={d?.thumbnail} className="lazy nft__item_preview" alt=""/>
                        </span>
                      </Outer>
                    </div>
                    <div className="nft__item_info">
                        <span onClick={()=> window.open("/#", "_self")}>
                            <h4>{d?.name}</h4>
                            {/* <span>{d?.description}</span> */}
                        </span>
                        <div className="nft__item_price">
                            {d?.salePrice} FLOW
                        </div>
                        <div className="nft__item_action">
                          {d?.listed ? 
                            <button className="btn-main">Buy Now</button>:
                            <span>Not Listed</span>
                          }
                        </div>
                        <div className="nft__item_like">
                            <i className="fa fa-heart"></i><span>0</span>
                        </div>                            
                    </div> 
                </div>
              </div>
              </CustomSlide>
            );})}
          </Slider>
        </div>
    );
}
