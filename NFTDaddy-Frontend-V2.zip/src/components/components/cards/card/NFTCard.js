import React from 'react'
import './nftCard.scss'
export default function NFTCard(props) {
    const { name, price, fileType, previewURL, userData } = props; 
    
    
  return (
    <div className="nftCard nft__item m-0">

        <div className="author_list_pp">
            <span>                                    
                <img className="lazy" src={userData?.avatarImage || "/img/author/author-1.jpg"} alt="" />
                <i className="fa fa-check"></i>
            </span>
            </div>
            <div className="nft__item_wrap">
                <span>
                    {fileType === "image"?
                        <img src={previewURL || "/img/collections/coll-item-3.jpg"} id="get_file_2" className="lazy nft__item_preview" alt="" />:
                        <img src="/img/collections/coll-item-3.jpg" id="get_file_2" className="lazy nft__item_preview" alt="" />
                    }
                </span>
            </div>
            <div className="nft__item_info">
                <span >
                    <h4>{name || 'No Name'}</h4>
                </span>
            <div className="nft__item_price">
                {price || '0.00'} FLOW
            </div>
            <button className='btn-main'><span>Buy Now</span></button>
            <div className="nft__item_like">
                <i className="fa fa-heart"></i><span>0</span>
            </div>
        </div>
    </div>
  )
}
