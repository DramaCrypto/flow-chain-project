import { MuiPickersUtilsProvider, DateTimePicker } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import './style.scss';
export default function DateTimePickerField({ label, value, onChange, classNAME}) {
  return (
    <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <DateTimePicker
      className={`myDatePicker ${classNAME}`}
        label={label}
        inputVariant="outlined"
        value={value}
        onChange={onChange}
      />
    </MuiPickersUtilsProvider>
  );
}
