import * as fcl from "@onflow/fcl"

export default function useAuth() {

  const logIn = async (redirect = true) => {
    await fcl.authenticate();
  }

  const logOut = async () => {
    await fcl.unauthenticate();
  }

  return { logIn, logOut }
}
