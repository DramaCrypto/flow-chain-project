// import {cleanObject} from "src/util/object"
import publicConfig from "./publicConfig"

export const CHAIN_ENV_MAINNET = "mainnet"
export const CHAIN_ENV_TESTNET = "testnet"
export const CHAIN_ENV_EMULATOR = "emulator"
export const LOADING = "LOADING"

// Exposed states of a Flow Transaction
export const IDLE = "IDLE"
export const PROCESSING = "PROCESSING"
export const SUCCESS = "SUCCESS"
export const ERROR = "ERROR"

// How long to pause on a success or error message
// before transitioning back to an IDLE state.
export const IDLE_DELAY = 1000

export const BASE_HTML_TITLE = "NFTDaddy Marketplace on Flow Blockchain"

// export const getParamsString = params => {
//   if (typeof params !== "object") return ""
//   return Object.keys(params).length === 0
//     ? ""
//     : `?${new URLSearchParams(cleanObject(params)).toString()}`
// }

export const paths = {
  root: "/",
  marketplace: "/marketplace",
  profile: address => `/profiles/${address}`,
  profileItem: (address, id) => `/profiles/${address}/items/${id}`,
  // apiMarketItemsList: params => `${publicConfig.apiMarketItemsList}${getParamsString(params)}`,
  apiListing: id => `${publicConfig.apiUrl}/v1/market/${id}`,
  apiSell: `${publicConfig.apiUrl}/v1/market/sell`,
  flowscanTx: txId => {
    if (publicConfig.chainEnv === CHAIN_ENV_EMULATOR) return null
    return `https://${publicConfig.chainEnv === CHAIN_ENV_TESTNET ? "testnet." : ""}flowscan.org/transaction/${txId}`
  },
  flowscanAcct: address => {
    if (publicConfig.chainEnv === CHAIN_ENV_EMULATOR) return null
    return `https://${publicConfig.chainEnv === CHAIN_ENV_TESTNET ? "testnet." : ""}flowscan.org/account/${address}`
  },
}

export const TRANSACTION_STATUS_MAP = {
  1: "Awaiting Finalization",
  2: "Awaiting Execution",
  3: "Awaiting Sealing",
  4: "Transaction Sealed",
  5: "Transaction Expired",
}

export const DECLINE_RESPONSE = "Declined: Externally Halted"
