const appTitle = "NFTDaddy Marketplace on Flow"

const chainEnv = process.env.REACT_APP_CHAIN_ENV
if (!chainEnv) throw new Error("Missing CHAIN_ENV")

const flowAccessApiUrl = process.env.REACT_APP_FLOW_ACCESS_API_URL
if (!flowAccessApiUrl)
  throw new Error("Missing FLOW_ACCESS_API_URL")

const appUrl = process.env.REACT_APP_APP_URL
if (!appUrl) throw new Error("Missing APP_URL")

const walletDiscovery = process.env.REACT_APP_WALLET_DISCOVERY
if (!walletDiscovery) throw new Error("Missing WALLET_DISCOVERY")

const apiUrl = process.env.REACT_APP_API_URL
if (!apiUrl) throw new Error("Missing API_URL")

const contractFungibleToken = process.env.REACT_APP_CONTRACT_FUNGIBLE_TOKEN
if (!contractFungibleToken)
  throw new Error("Missing CONTRACT_FUNGIBLE_TOKEN")

const contractNonFungibleToken =
  process.env.REACT_APP_CONTRACT_NON_FUNGIBLE_TOKEN
if (!contractNonFungibleToken)
  throw new Error("Missing CONTRACT_NON_FUNGIBLE_TOKEN")

const contractMetadataViews = process.env.REACT_APP_CONTRACT_METADATA_VIEWS
if (!contractMetadataViews)
  throw new Error("Missing CONTRACT_METADATA_VIEWS")

const flowAddress = process.env.REACT_APP_FLOW_ADDRESS
if (!flowAddress) throw new Error("Missing FLOW_ADDRESS")

const avatarUrl = process.env.REACT_APP_AVATAR_URL
if (!avatarUrl) throw new Error("Missing AVATAR_URL")

const contractDaddyNFT = process.env.REACT_APP_CONTRACT_DADDY_NFT
if (!contractDaddyNFT)
  throw new Error("Missing CONTRACT_DADDY_NFT")

const contractNftStorefront = process.env.REACT_APP_CONTRACT_NFT_STOREFRONT
if (!contractNftStorefront)
  throw new Error("Missing CONTRACT_NFT_STOREFRONT")

const contractNftStorefrontV2 = process.env.REACT_APP_CONTRACT_NFT_STOREFRONT_V2
if (!contractNftStorefrontV2)
  throw new Error("Missing CONTRACT_NFT_STOREFRONT_V2")

const contractFlowToken = process.env.REACT_APP_CONTRACT_FLOW_TOKEN
if (!contractFlowToken)
  throw new Error("Missing CONTRACT_FLOW_TOKEN")

const pinataApiKey = process.env.REACT_APP_PINATA_API_KEY
if (!pinataApiKey)
  throw new Error("Missing PINATA_API_KEY")

const pinataSecretApiKey = process.env.REACT_APP_PINATA_SECRET_API_KEY
if (!pinataSecretApiKey)
  throw new Error("Missing PINATA_SECRET_API_KEY")

const nftStorageApiKey = process.env.REACT_APP_NFT_STORAGE_API_KEY
if (!nftStorageApiKey)
  throw new Error("Missing NFT_STORAGE_API_KEY")

const publicConfig = {
  appTitle,
  faucetAddress: process.env.REACT_APP_FAUCET_ADDRESS,
  chainEnv,
  flowAccessApiUrl,
  appUrl,
  walletDiscovery,
  apiUrl,
  flowAddress,
  avatarUrl,
  contractFungibleToken,
  contractNonFungibleToken,
  contractMetadataViews,
  contractFlowToken,
  contractDaddyNFT,
  contractNftStorefront,
  contractNftStorefrontV2,
  pinataApiKey,
  pinataSecretApiKey,
  nftStorageApiKey,
}

export default publicConfig
