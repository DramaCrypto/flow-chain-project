const fcl = require("@onflow/fcl");
const t = require("@onflow/types")
const axios = require('axios');
const globalConfig = require('../config')();
const FlowService = require("../services/flow");
const { send } = require("@onflow/transport-grpc");
const fs = require('fs');
const path = require("path");

const NFTObjectModel = require('../models/NFTObjectModel');
const NFTEventModel = require('../models/NFTEventModel');
const UserModel = require('../models/UserModel');

const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

const flowService = new FlowService(
    globalConfig.MINTER_ADDRESS,
    globalConfig.MINTER_PRIVATE_KEY,
    globalConfig.MINTER_ACCOUNT_KEY_INDEX
)

const DADDY_NFT_DEPOSIT_EVENT = `A.${fcl.sansPrefix(globalConfig.DADDY_NFT_ADDRESS)}.DaddyNFT.Deposit`;
const NFT_STOREFRONT_LISTING_AVAILABLE_EVENT = `A.${fcl.sansPrefix(globalConfig.NFT_STOREFRONT_V2_ADDRESS)}.NFTStorefrontV2.ListingAvailable`;
const NFT_STOREFRONT_LISTING_COMPLETE_EVENT = `A.${fcl.sansPrefix(globalConfig.NFT_STOREFRONT_V2_ADDRESS)}.NFTStorefrontV2.ListingCompleted`;

const Sync = {
    fclConfig: async function () {
        fcl
            .config()
            .put("accessNode.api", globalConfig.FLOW_ACCESS_API_URL)
            .put("decoder.Type", val => val.staticType)
            .put("decoder.Enum", val => Number(val.fields[0].value.value))
            .put("sdk.transport", send)
            .put("0xFungibleToken", globalConfig.FUNGIBLE_TOKEN_ADDRESS)
            .put("0xNonFungibleToken", globalConfig.NON_FUNGIBLE_TOKEN_ADDRESS)
            .put("0xMetadataViews", globalConfig.METADATA_VIEWS_ADDRESS)
            .put("0xFlowToken", globalConfig.FLOW_TOKEN_ADDRESS)
            .put("0xNFTStorefront", globalConfig.NFT_STOREFRONT_ADDRESS)
            .put("0xNFTStorefrontV2", globalConfig.NFT_STOREFRONT_V2_ADDRESS)
            .put("0xDaddyNFT", globalConfig.DADDY_NFT_ADDRESS)
    },

    initializeAccount: async function () {
        const authorization = flowService.authorizeMinter();

        const initializeAccountTx = fs.readFileSync(path.join(__dirname, `../cadence/transactions/initialize_account.cdc`), "utf8");
        const result = await flowService.sendTx({
            transaction: initializeAccountTx,
            args: [],
            authorizations: [authorization],
            payer: authorization,
            proposer: authorization,
        });

        return result;
    },

    isAccountInitialized: async function (_address) {
        const isAccountInitializedScript = fs.readFileSync(path.join(__dirname, `../cadence/scripts/is_account_initialized.cdc`), "utf8");

        const result = await flowService.executeScript({
            script: isAccountInitializedScript,
            args: [
                fcl.arg(_address, t.Address)
            ]
        });

        return result.DaddyNFTMarket && result.DaddyNFT;
    },

    getAccountItem: async function (_address, _id) {
        const getAccountItemScript = fs.readFileSync(path.join(__dirname, `../cadence/scripts/get_account_item.cdc`), "utf8");

        const result = await flowService.executeScript({
            script: getAccountItemScript,
            args: [
                fcl.arg(_address, t.Address),
                fcl.arg(_id, t.UInt64)
            ]
        });

        return result;
    },

    getCurrentBlockHeight: async function () {
        if (fs.existsSync(`./currentBlock.save`)) {
            const data = fs.readFileSync(`./currentBlock.save`);
            return parseInt(data.toString());
        }
        return 74094712;
    },

    saveCurrentBlockHeight: async function (currentBlock) {
        fs.writeFileSync(`./currentBlock.save`, currentBlock.toString());
    },

    getEvents: async function (eventNames, fromBlock, toBlock) {
        let events = [];
        for (const eventName of eventNames) {
            try {
                const result = await fcl.send([
                    fcl.getEventsAtBlockHeightRange(eventName, fromBlock, toBlock)
                ]);
                const decoded = await fcl.decode(result);
                if (decoded.length > 0) {
                    events.push(...decoded);
                }
            } catch (e) {
                console.error(`Error retrieving events for block range fromBlock=${fromBlock} toBlock=${toBlock}`, e);
            }
        }

        if (events.length > 0) {
            events.sort((event1, event2) => {
                // order events by block height ascending
                if (event1.blockHeight > event2.blockHeight) {
                    return 1;
                } else if (event1.blockHeight < event2.blockHeight) {
                    return -1;
                }

                // if events are on the same block, order by transaction index
                if (event1.transactionIndex > event2.transactionIndex) {
                    return 1;
                } else if (event1.transactionIndex < event2.transactionIndex) {
                    return -1;
                }

                return 0;
            });
        }

        return events;
    },

    daddyNFTDepositEventHandler: async function (event) {
        const blockTimestamp = Math.round(Date.parse(event.blockTimestamp) / 1000);
        const blockHeight = event.blockHeight;

        const id = event.data.id;
        const to = event.data.to;

        console.log(`*** DEPOSIT (ID : ${id} TO : ${to})***`);

        const nftObject = await NFTObjectModel.findOne({ nftID: id });
        if (!nftObject) {
            const daddyNFT = await this.getAccountItem(to, id);

            const nftEvent = new NFTEventModel({
                eventType: "MINT",
                nftID: id,
                name: daddyNFT.name,
                thumbnail: daddyNFT.thumbnail,
                owner: to,
                salePrice: 0,
                eventTime: blockTimestamp,
            });
            await nftEvent.save();

            await NFTObjectModel.findOneAndUpdate({ nftID: id }, {
                name: daddyNFT.name,
                description: daddyNFT.description,
                thumbnail: daddyNFT.thumbnail,
                creator: to,
                owner: to,
                mintedTime: blockTimestamp,
                mintedBlock: blockHeight,
            }, { upsert: true, new: true });

        } else {
            await NFTObjectModel.findOneAndUpdate({ nftID: id }, {
                owner: to
            }, { upsert: true, new: true });
        }
    },

    nftStorefrontV2ListingAvailableEventHandler: async function (event) {
        const blockTimestamp = Math.round(Date.parse(event.blockTimestamp) / 1000);
        const blockHeight = event.blockHeight;

        const storefrontAddress = event.data.storefrontAddress;
        const listingResourceID = event.data.listingResourceID;
        const nftUUID = event.data.nftUUID;
        const nftID = event.data.nftID;
        const salePrice = event.data.salePrice;
        const expiry = event.data.expiry;

        console.log(`*** LISTED (ID : ${nftID} PRICE : ${salePrice})***`);

        const nftObject = await NFTObjectModel.findOne({ nftID: nftID });

        const nftEvent = new NFTEventModel({
            eventType: "LIST",
            nftID: nftID,
            name: nftObject?.name,
            thumbnail: nftObject?.thumbnail,
            owner: nftObject?.owner,
            salePrice: salePrice,
            eventTime: blockTimestamp,
        });
        await nftEvent.save();

        await NFTObjectModel.findOneAndUpdate({ nftID: nftID }, {
            listed: true,
            storefrontAddress: storefrontAddress,
            listingResourceID: listingResourceID,
            nftUUID: nftUUID,
            salePrice: salePrice,
            expiry: expiry,
            listedTime: blockTimestamp,
            listedBlock: blockHeight,
        }, { upsert: true, new: true });
    },

    nftStorefrontV2ListingCompleteEventHandler: async function (event) {
        const blockTimestamp = Math.round(Date.parse(event.blockTimestamp) / 1000);
        const blockHeight = event.blockHeight;

        const purchased = event.data.purchased;
        const nftID = event.data.nftID;

        console.log(`*** DELISTED (ID : ${nftID})***`);

        const nftObject = await NFTObjectModel.findOne({ nftID: nftID });

        const nftEvent = new NFTEventModel({
            eventType: purchased == true ? "SELL" : "DELIST",
            nftID: nftID,
            name: nftObject?.name,
            thumbnail: nftObject?.thumbnail,
            owner: nftObject?.owner,
            salePrice: purchased == true ? nftObject?.salePrice : 0.00,
            eventTime: blockTimestamp,
        });
        await nftEvent.save();

        await NFTObjectModel.findOneAndUpdate({ nftID: nftID }, {
            listed: false,
            storefrontAddress: "",
            listingResourceID: "",
            nftUUID: "",
            salePrice: 0.00,
            expiry: 0,
            listedTime: 0,
            listedBlock: 0,
        }, { upsert: true, new: true });

        if (purchased == true) {
            const user = await UserModel.findOne({ walletAddress: nftObject?.owner });
            await UserModel.findOneAndUpdate({ walletAddress: nftObject?.owner }, {
                soldAmount: (user?.soldAmount || 0) + (nftObject?.salePrice || 0)
            }, { upsert: true, new: true });
        }
    },

    execute: async function () {
        await this.fclConfig();
        const bInitialized = await this.isAccountInitialized(globalConfig.MINTER_ADDRESS);
        if (!bInitialized) {
            const tx = await this.initializeAccount();
            console.log("Account Initialize Tx : ", tx);
        }

        console.log("Start Event Polling");

        while (1) {
            try {
                let fromBlock = await this.getCurrentBlockHeight() + 1;
                let latestBlock = await flowService.getLatestBlockHeight();

                let toBlock = latestBlock;

                while (latestBlock >= fromBlock) {
                    if (latestBlock - fromBlock >= 200) {
                        toBlock = fromBlock + 200;
                    } else {
                        toBlock = latestBlock;
                    }

                    console.log(`Checking block range: fromBlock=${fromBlock} toBlock=${toBlock}`);

                    let eventNames = [
                        DADDY_NFT_DEPOSIT_EVENT,
                        NFT_STOREFRONT_LISTING_AVAILABLE_EVENT,
                        NFT_STOREFRONT_LISTING_COMPLETE_EVENT,
                    ]

                    let events = await this.getEvents(eventNames, fromBlock, toBlock);

                    for (let i = 0; i < events.length; i++) {
                        if (events[i].type == DADDY_NFT_DEPOSIT_EVENT) {
                            await this.daddyNFTDepositEventHandler(events[i]);
                        } else if (events[i].type == NFT_STOREFRONT_LISTING_AVAILABLE_EVENT) {
                            await this.nftStorefrontV2ListingAvailableEventHandler(events[i]);
                        } else if (events[i].type == NFT_STOREFRONT_LISTING_COMPLETE_EVENT) {
                            await this.nftStorefrontV2ListingCompleteEventHandler(events[i]);
                        }
                    }

                    await this.saveCurrentBlockHeight(toBlock);

                    fromBlock = toBlock + 1;
                }
                await this.saveCurrentBlockHeight(latestBlock);
            }
            catch (ex) {
                console.log(ex);
            }
            await sleep(1000);
        }
    }
}

module.exports = Sync;
