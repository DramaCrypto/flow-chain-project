const fs = require('fs');
const globalConfig = require('../config/index')();
const BaseController = require('./BaseController');
const UserModel = require('../models/UserModel');
const NFTEventModel = require('../models/NFTEventModel');
const NFTObjectModel = require('../models/NFTObjectModel');

module.exports = BaseController.extend({
    name: 'ApiController',

    getUserProfile: async function (req, res, next) {
        try {
            const walletAddress = req.params.walletAddress;

            if (!walletAddress) return res.send({ status: 'failed', exception: "Invalid Wallet Address" });

            let userProfile = await UserModel.findOne({ walletAddress: walletAddress });
            if (!userProfile) {
                const newUserProfile = new UserModel({
                    walletAddress: walletAddress
                });
                await newUserProfile.save();
            }
            userProfile = await UserModel.findOne({ walletAddress: walletAddress });

            return res.send({ status: 'success', userProfile: userProfile });
        }
        catch (ex) {
            console.log(ex);
            return res.send({ status: 'failed', exception: ex });
        }
    },

    updateUserProfile: async function (req, res, next) {
        try {
            const walletAddress = req.body.walletAddress;
            const name = req.body.name;
            const description = req.body.description;
            const avatarImage = req.body.avatarImage;
            const bannerImage = req.body.bannerImage;

            const twitter = req.body.twitter;
            const discord = req.body.discord;
            const instagram = req.body.instagram;
            const telegram = req.body.telegram;

            if (!walletAddress) return res.send({ status: 'failed', exception: "Invalid Wallet Address" });

            let userProfile = await UserModel.findOneAndUpdate({ walletAddress: walletAddress }, {
                name: name,
                description: description,
                avatarImage: avatarImage,
                bannerImage: bannerImage,

                twitter: twitter,
                discord: discord,
                instagram: instagram,
                telegram: telegram
            }, { upsert: true, new: true });

            return res.send({ status: 'success', userProfile: userProfile });
        }
        catch (ex) {
            return res.send({ status: 'failed', exception: ex });
        }
    },

    getUserList: async function (req, res, next) {
        try {
            const userList = await UserModel.find().sort({ soldAmount: -1 });

            return res.send({ status: 'success', userList: userList });
        }
        catch (ex) {
            return res.send({ status: 'failed', exception: ex });
        }
    },


    getNFTObjectList: async function (req, res, next) {
        try {
            let start = Number(req.query.start);
            let count = Number(req.query.count);
            const sortField = req.query.sortField;
            const sortOrder = req.query.sortOrder;
            const searchKey = req.query.searchKey;

            let findOpt = {};
            let sortOpt = {};

            if (searchKey && searchKey != "undefined") {
                findOpt["$or"] = [
                    {
                        name: {
                            $regex: searchKey,
                            $options: 'i'
                        }
                    },
                    {
                        creator: {
                            $regex: searchKey,
                            $options: 'i'
                        }
                    },
                    {
                        owner: {
                            $regex: searchKey,
                            $options: 'i'
                        }
                    },
                ]
            }

            if (sortField && sortOrder) {
                if (sortOrder == "asc") {
                    sortOpt[`${sortField}`] = 1;
                }
                else if (sortOrder == "desc") {
                    sortOpt[`${sortField}`] = -1;
                }
            }

            const nftList = await NFTObjectModel.find(findOpt).sort(sortOpt).skip(start).limit(count);
            const totalNftList = await NFTObjectModel.find(findOpt);

            return res.send({ status: 'success', totalCount: totalNftList.length, nftList: nftList });
        }
        catch (ex) {
            console.log(ex);
            return res.send({ status: 'failed', exception: ex });
        }
    },

    getNFTObjectDetail: async function (req, res, next) {
        try {
            const nftID = req.params.nftID;

            const nftObject = await NFTObjectModel.findOne({ nftID: nftID });

            return res.send({ status: 'success', nftDetail: nftObject });
        }
        catch (ex) {
            return res.send({ status: 'failed', exception: ex });
        }
    },

    getNFTEvents: async function (req, res, next) {
        try {
            const nftID = req.query.nftID;
            const walletAddress = req.query.walletAddress;

            let findOpt = {};

            if (nftID) {
                findOpt.nftID = nftID;
            }

            if (walletAddress) {
                findOpt.owner = walletAddress;
            }

            const events = await NFTEventModel.find(findOpt).sort({ eventTime: -1 });

            return res.send({ status: 'success', events: events });
        }
        catch (ex) {
            return res.send({ status: 'failed', exception: ex });
        }
    },
});