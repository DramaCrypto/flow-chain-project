let config = {
    port: 5000,
    mongo: {
        host: '127.0.0.1',
        port: 27017,
        db_name: 'NFTDADDY_DB'
    },
    MINTER_ADDRESS: "0x2128a710cdf03284",
    MINTER_PRIVATE_KEY: "380bdcd7a5f806a816b04eba231bd934661b30cf29e6ca01f5db48c6d20eb62b",
    MINTER_ACCOUNT_KEY_INDEX: 0,

    DADDY_NFT_ADDRESS: "0x2128a710cdf03284",

    METADATA_VIEWS_ADDRESS: '0x631e88ae7f1d7c20',
    FLOW_TOKEN_ADDRESS: '0x7e60df042a9c0868',
    FUNGIBLE_TOKEN_ADDRESS: "0x9a0766d93b6608b7",
    NON_FUNGIBLE_TOKEN_ADDRESS: '0x631e88ae7f1d7c20',
    NFT_STOREFRONT_ADDRESS: '0x2128a710cdf03284',
    NFT_STOREFRONT_V2_ADDRESS: '0x2128a710cdf03284',

    FLOW_ACCESS_API_URL: "https://access-testnet.onflow.org",
};

module.exports = function () {
    return config;
};