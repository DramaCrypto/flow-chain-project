let express = require('express');
let flash = require('connect-flash');
let path = require('path');
let session = require('express-session');
let mongoose = require('mongoose');
let cors = require('cors');
let bodyParser = require('body-parser');
let methodOverride = require('method-override');

let db_dumper = require('./services/db_dumper');
const Sync = require('./sync/Sync')

let app = express();

let config = require('./config')();
let apiRoute = require('./routes/apiRoute');

app.use(cors());
app.use(express.static(path.join(__dirname, "build")));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(bodyParser.json({ limit: '50mb', extended: true }));
app.use(methodOverride('X-HTTP-Method-Override'));
app.use(flash());
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,Content-type,Accept');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

mongoose.connect(`mongodb://${config.mongo.host}:${config.mongo.port}/${config.mongo.db_name}`, { useUnifiedTopology: true, useNewUrlParser: true }, async function (err, db) {
    let d = new Date();
    if (err) {
        console.log('[' + d.toLocaleString() + '] ' + 'Sorry, there is no mongo db server running.');
    } else {
        let attachDB = function (req, res, next) {
            req.db = db;
            next();
        };
        app.use('/api', attachDB, apiRoute);

        app.get('/*', (req, res) => {
            res.sendFile(path.join(__dirname, 'build', 'index.html'));
        });

        app.listen(config.port, async function () {
            console.log('[' + d.toLocaleString() + '] ' + 'Server listening...');
            await Sync.execute();
        });

        db_dumper.start();
    }
});