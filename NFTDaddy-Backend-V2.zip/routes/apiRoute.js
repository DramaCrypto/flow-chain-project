let express = require('express');
let router = express.Router();


let api_controller = require('../controllers/ApiController');

////////////////////////////// Metadata For Collection ///////////////////////////////

router.get('/getUserProfile/:walletAddress', function (req, res, next) {
    api_controller.getUserProfile(req, res, next);
});

router.post('/updateUserProfile', function (req, res, next) {
    api_controller.updateUserProfile(req, res, next);
});

router.get('/getUserList', function (req, res, next) {
    api_controller.getUserList(req, res, next);
});


router.get('/getNFTObjectList', function (req, res, next) {
    api_controller.getNFTObjectList(req, res, next);
});

router.get('/getNFTObjectDetail/:nftID', function (req, res, next) {
    api_controller.getNFTObjectDetail(req, res, next);
});

router.get('/getNFTEvents', function (req, res, next) {
    api_controller.getNFTEvents(req, res, next);
});

module.exports = router;