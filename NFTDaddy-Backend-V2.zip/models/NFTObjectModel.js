let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let NFTObjectSchema = new Schema({
    nftID: Number,

    name: String,
    description: String,
    thumbnail: String,
    creator: String,
    owner: String,
    mintedTime: Number,
    mintedBlock: Number,

    listed: { type: Boolean, default: false },
    storefrontAddress: { type: String, default: "" },
    listingResourceID: { type: String, default: "" },
    nftUUID: { type: String, default: "" },
    salePrice: { type: Number, default: 0.00 },
    expiry: { type: Number, default: 0 },
    listedTime: { type: Number, default: 0 },
    listedBlock: { type: Number, default: 0 },
});

module.exports = mongoose.model('nft_objects', NFTObjectSchema);