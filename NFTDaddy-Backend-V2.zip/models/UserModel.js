let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let UserSchema = new Schema({
    walletAddress: String,

    name: String,
    description: String,
    avatarImage: String,
    bannerImage: String,

    twitter: String,
    discord: String,
    instagram: String,
    telegram: String,

    soldAmount: { type: Number, default: 0.00 },
});

module.exports = mongoose.model('users', UserSchema);