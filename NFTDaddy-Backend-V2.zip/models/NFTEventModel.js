let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let NFTEventSchema = new Schema({
    eventType: String,
    nftID: Number,
    name: String,
    thumbnail: String,
    owner: String,
    salePrice: Number,
    eventTime: Number,
});

module.exports = mongoose.model('nft_events', NFTEventSchema);